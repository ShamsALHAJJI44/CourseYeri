﻿// Utils/PasswordHelper.cs
using System.Security.Cryptography;
using System.Text;

namespace WebProject1.Utils
{
    public static class PasswordHelper
    {
        private const int Iterations = 100_000;
        private const int SaltSize = 16;      // 128-bit
        private const int KeySize = 32;       // 256-bit

        public static (string hash, string salt) Hash(string password)
        {
            using var rng = RandomNumberGenerator.Create();
            var saltBytes = new byte[SaltSize];
            rng.GetBytes(saltBytes);

            var hashBytes = Rfc2898DeriveBytes.Pbkdf2(
                Encoding.UTF8.GetBytes(password),
                saltBytes,
                Iterations,
                HashAlgorithmName.SHA256,
                KeySize);

            return (Convert.ToBase64String(hashBytes),
                    Convert.ToBase64String(saltBytes));
        }

        public static bool Verify(string password, string hashBase64, string saltBase64)
        {
            var saltBytes = Convert.FromBase64String(saltBase64);
            var hashToCompare = Rfc2898DeriveBytes.Pbkdf2(
                password,
                saltBytes,
                Iterations,
                HashAlgorithmName.SHA256,
                KeySize);

            return CryptographicOperations.FixedTimeEquals(
                Convert.FromBase64String(hashBase64),
                hashToCompare);
        }
    }
}
