﻿using Microsoft.AspNetCore.Razor.TagHelpers;

namespace WebProject1.TagHelpers
{
    [HtmlTargetElement("timeago", Attributes = "value")]
    public class TimeAgoTagHelper : TagHelper
    {
        [HtmlAttributeName("value")]
        public DateTime Value { get; set; }

        // تنسيق العنوان (tooltip)
        public string? TitleFormat { get; set; } = "yyyy-MM-dd HH:mm";

        public override void Process(TagHelperContext context, TagHelperOutput output)
        {
            output.TagName = "time";
            output.Attributes.SetAttribute("datetime", Value.ToString("o"));
            output.Attributes.SetAttribute("title", Value.ToString(TitleFormat));
            output.Attributes.SetAttribute("data-timeago", "true");
            output.Content.SetContent(ToTurkishRelative(Value, DateTime.Now));
        }

        private static string ToTurkishRelative(DateTime then, DateTime now)
        {
            var ts = now - then;
            if (ts.TotalSeconds < 45) return "az önce";
            if (ts.TotalMinutes < 2) return "1 dakika önce";
            if (ts.TotalMinutes < 60) return $"{(int)ts.TotalMinutes} dakika önce";
            if (ts.TotalHours < 2) return "1 saat önce";
            if (ts.TotalHours < 24) return $"{(int)ts.TotalHours} saat önce";

            var days = (int)ts.TotalDays;
            if (days == 1) return "dün";
            if (days < 7) return $"{days} gün önce";
            if (days < 30) return $"{days / 7} hafta önce";
            if (days < 365) return $"{days / 30} ay önce";
            return $"{days / 365} yıl önce";
        }
    }
}
