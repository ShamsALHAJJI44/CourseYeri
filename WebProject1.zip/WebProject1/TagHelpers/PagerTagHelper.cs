﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.AspNetCore.Mvc.ViewFeatures;
using Microsoft.AspNetCore.Razor.TagHelpers;

namespace WebProject1.TagHelpers
{
    [HtmlTargetElement("pager")]
    public class PagerTagHelper : TagHelper
    {
        private readonly IUrlHelperFactory _urlHelperFactory;
        public PagerTagHelper(IUrlHelperFactory urlHelperFactory) => _urlHelperFactory = urlHelperFactory;

        [ViewContext, HtmlAttributeNotBound]
        public ViewContext? ViewContext { get; set; }

        // مدخلات
        public int Page { get; set; } = 1;
        public bool HasNext { get; set; }
        public string Action { get; set; } = "Index";
        public string Controller { get; set; } = "UserHome";
        public string? Q { get; set; }
        public int? CategoryId { get; set; }
        public bool FavoritesOnly { get; set; }

        public override void Process(TagHelperContext ctx, TagHelperOutput output)
        {
            output.TagName = "nav";
            output.Attributes.SetAttribute("class", "pager");

            var url = _urlHelperFactory.GetUrlHelper(ViewContext!);

            string Build(int page) => url.Action(Action, Controller, new
            {
                page,
                q = Q,
                categoryId = CategoryId,
                favoritesOnly = FavoritesOnly
            })!;

            string prevHref = Page > 1 ? Build(Page - 1) : "#";
            string nextHref = HasNext ? Build(Page + 1) : "#";

            var prev = $"<a class=\"page-link {(Page <= 1 ? "disabled" : "")}\" href=\"{prevHref}\">Önceki</a>";
            var info = $"<span class=\"page-info\">Sayfa {Page}</span>";
            var next = $"<a class=\"page-link {(!HasNext ? "disabled" : "")}\" href=\"{nextHref}\">Sonraki</a>";

            output.Content.SetHtmlContent(prev + info + next);
        }
    }
}
