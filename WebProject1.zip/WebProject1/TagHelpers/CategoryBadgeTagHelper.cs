﻿using Microsoft.AspNetCore.Razor.TagHelpers;
using System.Globalization;

namespace WebProject1.TagHelpers
{
    [HtmlTargetElement("cat-badge", Attributes = "name")]
    public class CategoryBadgeTagHelper : TagHelper
    {
        [HtmlAttributeName("name")]
        public string? Name { get; set; }

        public override void Process(TagHelperContext ctx, TagHelperOutput output)
        {
            output.TagName = "span";
            var (klass, text) = MapBadge(Name);
            output.Attributes.SetAttribute("class", $"badge {klass}");
            output.Content.SetContent(text);
        }

        private static (string klass, string text) MapBadge(string? name)
        {
            var n = (name ?? "").Trim().ToLower(new CultureInfo("tr-TR"));
            return n switch
            {
                "yapay zeka" => ("text-bg-primary", "Yapay Zeka"),
                "programlama" => ("text-bg-info", "Programlama"),
                "mobil geliştirme" => ("text-bg-success", "Mobil Geliştirme"),
                "veri bilimi" => ("text-bg-warning", "Veri Bilimi"),
                "siber güvenlik" => ("text-bg-danger", "Siber Güvenlik"),
                _ when string.IsNullOrEmpty(n) => ("text-bg-secondary", "Genel"),
                _ => ("text-bg-secondary", CultureInfo.CurrentCulture.TextInfo.ToTitleCase(n))
            };
        }
    }
}
