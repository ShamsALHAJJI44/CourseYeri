﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Threading.Tasks;
using WebProject1.Services;

namespace WebProject1.Controllers
{
    public class DiagEmailController : Controller
    {
        private readonly IEmailSender _email;
        private readonly IConfiguration _config;

        public DiagEmailController(IEmailSender email, IConfiguration config)
        {
            _email = email;
            _config = config;
        }

        // 1) يطبع القيم المقروءة من appsettings (مقنّعة)
        // GET: /diag-email/config
        [HttpGet("/diag-email/config")]
        public IActionResult Config()
        {
            var from = _config["Email:From"];
            var pass = _config["Email:AppPassword"];
            var display = _config["Email:DisplayName"];

            return Json(new
            {
                From = from,
                AppPasswordLoaded = string.IsNullOrWhiteSpace(pass) ? "NO" : $"YES (len={pass.Length})",
                DisplayName = display
            });
        }

        // 2) يجرّب الإرسال وبيرجّع النتيجة كنص
        // GET: /diag-email/send?to=you@example.com
        [HttpGet("/diag-email/send")]
        public async Task<IActionResult> Send([FromQuery] string to)
        {
            if (string.IsNullOrWhiteSpace(to))
                to = _config["Email:From"] ?? "";


            try
            {
                await _email.SendAsync(to, "Test Email", "<b>Merhaba!</b> Bu bir test mailidir.");
                return Content($"OK: mail sent to {to}");
            }
            catch (Exception ex)
            {
                return Content("FAILED: " + ex.Message + Environment.NewLine + ex.ToString());
            }
        }
    }
}
