﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using WebProject1.Data;
using WebProject1.Models;
using WebProject1.Utils;
using Microsoft.AspNetCore.Authorization;

public class AccountController : Controller
{
    private readonly ApplicationDbContext _context;
    private const string SESSION_ADMIN_USERNAME = "AdminUsername";
    private const string SESSION_ADMIN_ID = "AdminId";
    private const string SESSION_ROLE = "Role";

    public AccountController(ApplicationDbContext context) => _context = context;

    [HttpGet, AllowAnonymous]
    public IActionResult Login(string? returnUrl = null)
    {
        if (HttpContext.Session.GetString(SESSION_ROLE) == "admin")
            return RedirectToAction("Index", "Dashboard", new { area = "Admin" });

        return View(new LoginVM { ReturnUrl = returnUrl });
    }

    [HttpPost, ValidateAntiForgeryToken, AllowAnonymous]
    public IActionResult Login(LoginVM vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var uname = (vm.Username ?? "").Trim().ToLower();
        var password = (vm.Password ?? "").Trim();

        var user = _context.Users.FirstOrDefault(u =>
            u.Role != null && u.Role.ToLower() == "admin" &&
            ((u.Username ?? "").ToLower() == uname || (u.Email ?? "").ToLower() == uname));

        if (user is null)
        {
            ModelState.AddModelError(string.Empty, "Kullanıcı adı veya şifre hatalı.");
            return View(vm);
        }

        var ok = false;

        // تحقّق آمن: لو قيم مش Base64 ما نطيّر الابلكيشن
        if (!string.IsNullOrWhiteSpace(user.PasswordHash) && !string.IsNullOrWhiteSpace(user.PasswordSalt))
        {
            try
            {
                ok = PasswordHelper.Verify(password, user.PasswordHash!, user.PasswordSalt!);
            }
            catch
            {
                ok = false; // إذا كانت القيم تالفة اعتبر التحقق فاشل
            }
        }
        else if (!string.IsNullOrEmpty(user.Password) && user.Password == password)
        {
            // ترقية الحسابات القديمة إلى Hash/Salt
            ok = true;
            var (hash, salt) = PasswordHelper.Hash(password);
            user.PasswordHash = hash;
            user.PasswordSalt = salt;
            user.Password = null;
            _context.SaveChanges();
        }

        if (!ok)
        {
            ModelState.AddModelError(string.Empty, "Kullanıcı adı veya şifre hatalı.");
            return View(vm);
        }

        // نجاح الدخول
        HttpContext.Session.SetString(SESSION_ADMIN_USERNAME, user.Username);
        HttpContext.Session.SetInt32(SESSION_ADMIN_ID, user.Id);
        HttpContext.Session.SetString(SESSION_ROLE, "admin");

        // اختصر التعقيد: وجّه مباشرة للداشبورد
        return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
    }

    [HttpGet]
    public IActionResult Logout()
    {
        HttpContext.Session.Clear();
        return RedirectToAction(nameof(Login));
    }

    [HttpGet, AllowAnonymous]
    public IActionResult ForgotPassword() => View(new ForgotPasswordVM());

    [HttpPost, ValidateAntiForgeryToken, AllowAnonymous]
    public IActionResult ForgotPassword(ForgotPasswordVM vm)
    {
        if (!ModelState.IsValid) return View(vm);
        var key = (vm.UsernameOrEmail ?? "").Trim();
        var user = _context.Users.FirstOrDefault(u =>
            (u.Username == key || u.Email == key) &&
            u.Role != null && u.Role.ToLower() == "admin");

        if (user != null)
        {
            user.ResetToken = Guid.NewGuid().ToString("N");
            user.ResetTokenExpiresAt = DateTime.UtcNow.AddMinutes(15);
            _context.SaveChanges();
            TempData["ResetLink"] = Url.Action("ResetPassword", "Account",
                new { token = user.ResetToken }, Request.Scheme);
        }

        ViewBag.Msg = "Eğer bilgiler doğruysa, parola sıfırlama bağlantısı oluşturuldu.";
        return View(new ForgotPasswordVM());
    }

    [HttpGet, AllowAnonymous]
    public IActionResult ResetPassword(string token)
    {
        if (string.IsNullOrWhiteSpace(token)) return NotFound();

        var user = _context.Users.FirstOrDefault(u =>
            u.ResetToken == token && u.ResetTokenExpiresAt > DateTime.UtcNow);

        if (user == null)
        {
            ViewBag.Error = "Bağlantı geçersiz veya süresi dolmuş.";
            return View("ResetPasswordInvalid");
        }

        return View(new ResetPasswordVM { Token = token });
    }

    [HttpPost, ValidateAntiForgeryToken, AllowAnonymous]
    public IActionResult ResetPassword(ResetPasswordVM vm)
    {
        if (!ModelState.IsValid) return View(vm);

        var user = _context.Users.FirstOrDefault(u =>
            u.ResetToken == vm.Token && u.ResetTokenExpiresAt > DateTime.UtcNow);

        if (user == null)
        {
            ViewBag.Error = "Bağlantı geçersiz veya süresi dolmuş.";
            return View("ResetPasswordInvalid");
        }

        var (hash, salt) = PasswordHelper.Hash(vm.NewPassword);
        user.PasswordHash = hash;
        user.PasswordSalt = salt;
        user.Password = null;
        user.ResetToken = null;
        user.ResetTokenExpiresAt = null;
        _context.SaveChanges();

        TempData["LoginMsg"] = "Şifre başarıyla güncellendi. Lütfen giriş yapın.";
        return RedirectToAction(nameof(Login));
    }
}


