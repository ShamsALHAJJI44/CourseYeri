﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Models;
using System.Linq;
using WebProject1.Services;
using WebProject1.Models.Enums;
using WebProject1.Models.ViewModels;
using System.Net;
using System.Net.Mail;

namespace WebProject1.Controllers
{
    //[Route("[controller]")]
    public class PaymentController : Controller
    {
        private readonly ApplicationDbContext _ctx;
        private readonly INotificationService _notifService;
        private readonly IEmailSender _email;
        private readonly IConfiguration _config;


        public PaymentController(
     ApplicationDbContext ctx,
     INotificationService notifService,
     IEmailSender email,
     IConfiguration config)
        {
            _ctx = ctx;
            _notifService = notifService;
            _email = email;       // هون تربطه
            _config = config;
        }
        private async Task SendPaymentReceiptEmailAsync(string toEmail, string displayName, Payment payment, PaymentInstallment inst)
        {
            if (string.IsNullOrWhiteSpace(toEmail)) return;

            // رابط التفاصيل
            var link = Url.Action(nameof(Details), "Payment", new { id = payment.Id }, Request.Scheme);

            // قالب مختصر وواضح (تركي)
            var html = $@"
        <div style='font-family:Arial,Helvetica,sans-serif; line-height:1.6'>
            <h2>Ödeme Onayı</h2>
            <p>Merhaba {(string.IsNullOrWhiteSpace(displayName) ? "öğrenci" : displayName)},</p>
            <p>#{inst.Id} numaralı taksit ödemeniz başarıyla alındı.</p>
            <ul>
                <li><b>Kurs:</b> {payment.Enrollment?.Course?.Title}</li>
                <li><b>Tutar:</b> {inst.Amount:N2} ₺</li>
                <li><b>Tarih:</b> {(inst.PaidAt ?? DateTime.Now):yyyy-MM-dd HH:mm}</li>
            </ul>
            <p>Detaylar için: <a href='{link}'>Ödeme Detayı</a></p>
            <hr/>
            <small>Bu mesaj sistem tarafından otomatik gönderilmiştir.</small>
        </div>";

            await _email.SendAsync(toEmail, "Ödeme Onayı", html);
        }

        // ===== Helpers (ADDED) =====
        private void SendNotification(int userId, string title, string message, int? paymentId = null, int? installmentId = null, string? linkUrl = null)
        {
            try
            {
                var n = new Notification
                {
                    UserId = userId,
                    Title = title,
                    Message = message,
                    PaymentId = paymentId,
                    InstallmentId = installmentId,
                    LinkUrl = linkUrl,
                    CreatedAt = DateTime.Now,
                    IsRead = false
                };
                _ctx.Notifications.Add(n);
                _ctx.SaveChanges();
            }
            catch { /* ignore on purpose */ }
        }

        private void SendEmail(string toEmail, string subject, string htmlBody)
        {
            try
            {
                var from = _config["Email:From"];
                var appPassword = _config["Email:AppPassword"];
                var displayName = _config["Email:DisplayName"] ?? "CourseYeri";

                if (string.IsNullOrWhiteSpace(from) || string.IsNullOrWhiteSpace(appPassword))
                    return;

                using var smtp = new SmtpClient("smtp.gmail.com", 587)
                {
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(from, appPassword),
                    Timeout = 10000
                };

                using var mail = new MailMessage
                {
                    From = new MailAddress(from, displayName),
                    Subject = subject ?? string.Empty,
                    Body = htmlBody ?? string.Empty,
                    IsBodyHtml = true
                };
                mail.To.Add(toEmail);

                smtp.Send(mail); // أو استعمل SendMailAsync لو بدك Async
            }
            catch (Exception ex)
            {
                // لا تبلع الخطأ بصمت — على الأقل سجّله:
                Console.WriteLine("Email send failed: " + ex.Message);
            }
        }

        // GET: /Payment/Method?courseId=5
        [HttpGet()]
        public IActionResult Method(int courseId)
        {
            var course = _ctx.Courses.FirstOrDefault(c => c.Id == courseId);
            if (course == null) return NotFound();

            ViewBag.CourseId = courseId;
            ViewBag.Course = course;
            return View();
        }

        // POST: /Payment/Method
        [HttpPost()]
        [ValidateAntiForgeryToken]
        public IActionResult MethodPost(int courseId, string method)
        {
            method = string.IsNullOrWhiteSpace(method) ? "full" : method.ToLower();
            return RedirectToAction("Confirm", new { courseId, method });
        }

        // GET: /Payment/Confirm
        [HttpGet()]
        public IActionResult Confirm(int courseId, string method)
        {
            var course = _ctx.Courses.FirstOrDefault(c => c.Id == courseId);
            if (course == null) return NotFound();

            ViewBag.Method = string.IsNullOrWhiteSpace(method) ? "full" : method.ToLower();
            return View(course);
        }

       
        // POST: /Payment/Confirm
        [HttpPost()]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmPost(int courseId, string method)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                var ret = Url.Action("SelectType", "UserHome", new { id = courseId });
                return RedirectToAction("Login", "UserAccount", new { returnUrl = ret });
            }

            var course = await _ctx.Courses.FindAsync(courseId);
            if (course == null) return NotFound();

            method = (method ?? "full").ToLowerInvariant();

            // 1) Enrollment (varsa al, yoksa oluştur)
            var enr = await _ctx.Enrollments
                .FirstOrDefaultAsync(e => e.UserId == userId && e.CourseId == courseId);

            if (enr == null)
            {
                enr = new Enrollment
                {
                    UserId = userId.Value,
                    CourseId = courseId,
                    EnrollmentDate = DateTime.Now
                };
                _ctx.Enrollments.Add(enr);
                await _ctx.SaveChangesAsync();
            }

            // 2) Payment oluştur
            var payment = new Payment
            {
                EnrollmentId = enr.Id,
                Method = method == "installments" ? PaymentMethod.Installments : PaymentMethod.Full,
                Status = method == "installments" ? PaymentStatus.InstallmentOngoing : PaymentStatus.PaidFull,
                TotalAmount = course.Price,
                CreatedAt = DateTime.Now,
                Installments = new List<PaymentInstallment>()
            };

            if (method == "installments")
            {
                var half = Math.Round(course.Price / 2m, 2);

                // İlk taksit: ödeme zamanı bugün ama henüz ödenmedi
                payment.Installments.Add(new PaymentInstallment
                {
                    Amount = half,
                    DueDate = DateTime.Today,
                    IsPaid = false
                });
                // İkinci taksit: 15 gün sonra
                payment.Installments.Add(new PaymentInstallment
                {
                    Amount = half,
                    DueDate = DateTime.Today.AddDays(15),
                    IsPaid = false
                });
            }
            else
            {
                // Peşin ödeme → hemen ödenmiş kabul
                payment.Installments.Add(new PaymentInstallment
                {
                    Amount = course.Price,
                    DueDate = DateTime.Today,
                    IsPaid = true,
                    PaidAt = DateTime.Now
                });
            }

            _ctx.Payments.Add(payment);
            await _ctx.SaveChangesAsync();

            // 3) Bildirim ekle
            await _notifService.AddAsync(new Notification
            {
                UserId = enr.UserId,
                Title = "Yeni Ödeme",
                Message = $"#{payment.Id} numaralı ödeme kaydedildi.",
                PaymentId = payment.Id,
                LinkUrl = Url.Action(nameof(Details), "Payment", new { id = payment.Id }, Request.Scheme),
                CreatedAt = DateTime.Now,
                IsRead = false
            });

            await _notifService.AddAsync(new Notification
            {
                Title = "Yeni Kullanıcı Ödemesi",
                Message = $"Kullanıcı #{enr.UserId}, {course.Title} kursu için ödeme yaptı.",
                PaymentId = payment.Id,
                CreatedAt = DateTime.Now,
                IsForAdmin = true,
                IsRead = false,
                LinkUrl = $"/AdminNotifications/PaymentDetails/{payment.Id}"
            });

            // 4) Eğer peşin ödeme ise → mail gönder
            if (method == "full")
            {
                var user = await _ctx.Users.FindAsync(enr.UserId);
                if (user != null && !string.IsNullOrWhiteSpace(user.Email))
                {
                    var inst = payment.Installments.First();
                    await SendPaymentReceiptEmailAsync(
                        user.Email,
                        string.IsNullOrWhiteSpace(user.Username) ? user.Email.Split('@').First() : user.Username,
                        payment,
                        inst
                    );
                }
            }

            // 5) Mesaj + yönlendirme
            TempData["PaymentOk"] = method == "installments"
                ? "Taksitli ödeme oluşturuldu. İlk taksit için ödeme yapmanız gerekiyor."
                : "Peşin ödeme başarıyla tamamlandı.";

            return RedirectToAction(nameof(Details), new { id = payment.Id });
        }


        // GET: /Payment/Payments
        // GET: /Payment/Payments
        [HttpGet()]
        public async Task<IActionResult> Payments(string? search, int page = 1, int pageSize = 5)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "UserAccount");

            // base query
            var q = _ctx.Payments
                .Include(p => p.Enrollment).ThenInclude(e => e.Course)
                .Include(p => p.Installments)
                .Where(p => p.Enrollment.UserId == userId);

            // filter by keyword(s)
            string s = (search ?? "").Trim();
            string sl = s.ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                // عنوان الكورس
                q = q.Where(p => p.Enrollment.Course.Title.Contains(s));

                // كلمات مفتاحية شائعة
                if (sl.Contains("peşin"))
                    q = q.Where(p => p.Method == PaymentMethod.Full);
                if (sl.Contains("taksit"))
                    q = q.Where(p => p.Method == PaymentMethod.Installments);
                if (sl.Contains("ödendi") || sl.Contains("tam"))
                    q = q.Where(p => p.Status == PaymentStatus.PaidFull);
                if (sl.Contains("devam"))
                    q = q.Where(p => p.Status == PaymentStatus.InstallmentOngoing);
                if (sl.Contains("gecik"))
                    q = q.Where(p => p.Status == PaymentStatus.Overdue);
            }

            // pagination counts
            var totalCount = await q.CountAsync();
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            if (page < 1) page = 1;
            if (totalPages > 0 && page > totalPages) page = totalPages;

            // page data
            var payments = await q
                .OrderByDescending(p => p.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            // map to VM
            var list = payments.Select(p =>
            {
                var vm = new PaymentVM
                {
                    Id = p.Id,
                    CourseTitle = p.Enrollment.Course?.Title ?? "(Kurs)",
                    TotalAmount = p.TotalAmount,
                    CreatedAt = p.CreatedAt,
                    Method = p.Method == PaymentMethod.Full ? "Peşin" : "Taksit",
                    Status = p.Status == PaymentStatus.PaidFull
                                ? "Ödendi (Tam)"
                                : p.Status == PaymentStatus.InstallmentOngoing
                                    ? "Taksit (Devam Ediyor)"
                                    : p.Status.ToString(),
                    IsFullPaid = p.Status == PaymentStatus.PaidFull
                };

                foreach (var ins in p.Installments.OrderBy(i => i.DueDate))
                {
                    var overdue = !ins.IsPaid && DateTime.Now.Date > ins.DueDate.Date;
                    var dueSoon = !ins.IsPaid && !overdue && (ins.DueDate.Date - DateTime.Now.Date).TotalDays <= 3;

                    vm.Installments.Add(new PaymentInstallmentVM
                    {
                        Id = ins.Id,
                        Amount = ins.Amount,
                        DueDate = ins.DueDate,
                        IsPaid = ins.IsPaid,
                        PaidAt = ins.PaidAt,
                        IsOverdue = overdue,
                        IsDueSoon = dueSoon
                    });
                }

                return vm;
            }).ToList();

            // (اختياري) منطق التذكير كما عندك — يبقى كما هو:
            foreach (var p in payments)
            {
                foreach (var i in p.Installments)
                {
                    if (!i.IsPaid && i.DueDate.Date <= DateTime.Today.AddDays(3))
                    {
                        if (!await _notifService.ExistsSimilarAsync(
                                p.Enrollment.UserId,
                                "Yaklaşan Taksit",
                                $"Taksit #{i.Id} için son tarih: {i.DueDate:yyyy-MM-dd}.",
                                p.Id,
                                i.Id))
                        {
                            await _notifService.AddAsync(new Notification
                            {
                                UserId = p.Enrollment.UserId,
                                Title = "Yaklaşan Taksit",
                                Message = $"Taksit #{i.Id} için son tarih: {i.DueDate:yyyy-MM-dd}.",
                                PaymentId = p.Id,
                                InstallmentId = i.Id,
                                CreatedAt = DateTime.Now,
                                IsRead = false
                            });
                        }
                    }

                    if (!i.IsPaid && i.DueDate.Date < DateTime.Today)
                    {
                        if (!await _notifService.ExistsSimilarAsync(
                                p.Enrollment.UserId,
                                "Gecikmiş Taksit",
                                $"Taksit #{i.Id} gecikti! Son tarih: {i.DueDate:yyyy-MM-dd}.",
                                p.Id,
                                i.Id))
                        {
                            await _notifService.AddAsync(new Notification
                            {
                                UserId = p.Enrollment.UserId,
                                Title = "Gecikmiş Taksit",
                                Message = $"Taksit #{i.Id} gecikti! Son tarih: {i.DueDate:yyyy-MM-dd}.",
                                PaymentId = p.Id,
                                InstallmentId = i.Id,
                                CreatedAt = DateTime.Now,
                                IsRead = false
                            });
                        }
                    }
                }
            }

            // viewbag for view
            ViewBag.Search = s;
            ViewBag.Page = page;
            ViewBag.TotalPages = totalPages;

            return View(list);
        }

        // GET: /Payment/Agreement
        [HttpGet]
        public IActionResult Agreement(int courseId)
        {
            var selectedId = HttpContext.Session.GetInt32("SelectedCourseId") ?? courseId;
            var selectedType = HttpContext.Session.GetString("SelectedCourseType");

            if (selectedId == 0) return RedirectToAction("Index", "UserHome");

            var vm = new AgreementVM { CourseId = selectedId, Type = selectedType, Accepted = false };
            return View(vm); // يرسم صفحة الشروط مع زر "أوافق"
        }

        // POST /Payment/Agreement (إرسال الموافقة)
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Agreement(AgreementVM vm)
        {
            if (!vm.Accepted)
            {
                ModelState.AddModelError(nameof(vm.Accepted), "Lütfen sözleşmeyi onaylayın.");
                return View(vm);
            }

            
            return RedirectToAction("Payments", "UserHome", new { courseId = vm.CourseId });
           
        }
    


        // ✅ GET: /Payment/Details/5
        [HttpGet()]
        public IActionResult Details(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "UserAccount");

            var payment = _ctx.Payments
                .Include(p => p.Enrollment).ThenInclude(e => e.Course)
                .Include(p => p.Installments)
                .FirstOrDefault(p => p.Id == id && p.Enrollment.UserId == userId);

            if (payment == null) return NotFound();

            var vm = new PaymentVM
            {
                Id = payment.Id,
                CourseTitle = payment.Enrollment?.Course?.Title ?? "",
                TotalAmount = payment.TotalAmount,
                Method = payment.Method == PaymentMethod.Full ? "Peşin" : "Taksit",
                Status = payment.Status == PaymentStatus.PaidFull ? "Ödendi (Tam)" :
                         payment.Status == PaymentStatus.InstallmentOngoing ? "Taksit (Devam Ediyor)" : payment.Status.ToString(),
                CreatedAt = payment.CreatedAt
            };

            foreach (var ins in payment.Installments.OrderBy(i => i.DueDate))
            {
                var overdue = !ins.IsPaid && ins.DueDate.Date < DateTime.Today;
                var dueSoon = !ins.IsPaid && !overdue && (ins.DueDate.Date - DateTime.Today).TotalDays <= 3;

                vm.Installments.Add(new PaymentInstallmentVM
                {
                    Id = ins.Id,
                    Amount = ins.Amount,
                    DueDate = ins.DueDate,
                    IsPaid = ins.IsPaid,
                    PaidAt = ins.PaidAt,
                    IsOverdue = overdue,
                    IsDueSoon = dueSoon
                });
            }

            vm.Transactions = new List<TransactionVM>();
            if (payment.Method == PaymentMethod.Full)
            {
                vm.Transactions.Add(new TransactionVM
                {
                    Id = 1,
                    Amount = payment.TotalAmount,
                    Method = "Peşin",
                    Status = payment.Status == PaymentStatus.PaidFull ? "Başarılı" : "Bekliyor",
                    Date = payment.CreatedAt
                });
            }
            else
            {
                int seq = 1;
                foreach (var ins in payment.Installments.OrderBy(i => i.DueDate))
                {
                    if (ins.IsPaid)
                    {
                        vm.Transactions.Add(new TransactionVM
                        {
                            Id = seq++,
                            Amount = ins.Amount,
                            Method = "Online",
                            Status = "Başarılı",
                            Date = ins.PaidAt ?? ins.DueDate
                        });
                    }
                    else if (ins.DueDate.Date <= DateTime.Today)
                    {
                        vm.Transactions.Add(new TransactionVM
                        {
                            Id = seq++,
                            Amount = ins.Amount,
                            Method = "Online",
                            Status = "Bekliyor",
                            Date = ins.DueDate
                        });
                    }
                }
            }

            return View(vm);
        }

        // POST: /Payment/PayInstallment
        [HttpPost()]
        [ValidateAntiForgeryToken]
        public IActionResult PayInstallment(int installmentId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "UserAccount");

            var inst = _ctx.PaymentInstallments
                .Include(i => i.Payment).ThenInclude(p => p.Enrollment)
                .FirstOrDefault(i => i.Id == installmentId && i.Payment.Enrollment.UserId == userId);

            if (inst == null) return NotFound();

            if (!inst.IsPaid)
            {
                inst.IsPaid = true;
                inst.PaidAt = DateTime.Now;

                var payment = inst.Payment;
                _ctx.SaveChanges();

                var allPaid = _ctx.PaymentInstallments
                    .Where(i => i.PaymentId == payment.Id)
                    .All(i => i.IsPaid);

                if (allPaid)
                {
                    payment.Status = PaymentStatus.PaidFull;
                    _ctx.SaveChanges();
                }

                TempData["Ok"] = "İlgili taksit başarıyla ödendi.";
            }
            else
            {
                TempData["Info"] = "Bu taksit zaten ödenmiş.";
            }

            return RedirectToAction("Details", new { id = inst.PaymentId });
        }

        // POST: /Payment/StartOnlinePayment
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> StartOnlinePayment(int installmentId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "UserAccount");

            var payment = await _ctx.Payments
                .Include(p => p.Enrollment).ThenInclude(e => e.User) // ADDED
                .Include(p => p.Installments)
                .FirstOrDefaultAsync(p => p.Installments.Any(i => i.Id == installmentId)
                                          && p.Enrollment.UserId == userId);

            if (payment is null) return NotFound();
            var inst = payment.Installments.First(i => i.Id == installmentId);

            if (inst.IsPaid)
            {
                TempData["Info"] = "Bu taksit zaten ödendi.";
                return RedirectToAction(nameof(Details), new { id = inst.PaymentId });
            }
            if (inst.DueDate.Date > DateTime.Today)
            {
                TempData["Info"] = "Bu taksidin vadesi henüz gelmedi.";
                return RedirectToAction(nameof(Details), new { id = inst.PaymentId });
            }

            return RedirectToAction(nameof(Checkout), new { installmentId });
        }

        // GET: /Payment/Checkout
        [HttpGet]
        public async Task<IActionResult> Checkout(int installmentId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "UserAccount");

            var payment = await _ctx.Payments
                .Include(p => p.Enrollment).ThenInclude(e => e.User) // ADDED
                .Include(p => p.Installments)
                .FirstOrDefaultAsync(p => p.Installments.Any(i => i.Id == installmentId)
                                          && p.Enrollment.UserId == userId);

            if (payment is null) return NotFound();
            var inst = payment.Installments.First(i => i.Id == installmentId);
            if (inst is null) return NotFound();

            return View(inst);
        }


        // POST: /Payment/ConfirmPayment
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> ConfirmPayment(int installmentId, string result = "success")
        {
            // 0) جلسة المستخدم
            var sessionUserId = HttpContext.Session.GetInt32("UserId");
            if (sessionUserId == null)
                return RedirectToAction("Login", "UserAccount");

            // 1) نجيب الدفع مع كل ما نحتاجه (User + Course + Installments)
            var payment = await _ctx.Payments
                .Include(p => p.Enrollment).ThenInclude(e => e.User)
                .Include(p => p.Enrollment).ThenInclude(e => e.Course)
                .Include(p => p.Installments)
                .FirstOrDefaultAsync(p =>
                    p.Installments.Any(i => i.Id == installmentId) &&
                    p.Enrollment.UserId == sessionUserId);

            if (payment is null)
            {
                Console.WriteLine($"[Confirm] Payment not found for installment #{installmentId} / user {sessionUserId}");
                return NotFound();
            }

            var inst = payment.Installments.FirstOrDefault(i => i.Id == installmentId);
            if (inst is null)
            {
                Console.WriteLine($"[Confirm] Installment #{installmentId} not found inside payment #{payment.Id}");
                return NotFound();
            }

            var normalizedResult = (result ?? "").Trim().ToLowerInvariant();
            Console.WriteLine($"[Confirm] result={normalizedResult}, inst.IsPaid(before)={inst.IsPaid}, installmentId={installmentId}, paymentId={payment.Id}");

            var justPaidNow = false;

            if (normalizedResult == "success")
            {
                // 2) تحديث حالة القسط/الدفع (مرة واحدة فقط)
                if (!inst.IsPaid)
                {
                    inst.IsPaid = true;
                    inst.PaidAt = DateTime.Now;

                    var allPaid = payment.Installments.All(x => x.IsPaid);
                    payment.Status = allPaid ? PaymentStatus.PaidFull : PaymentStatus.InstallmentOngoing;

                    await _ctx.SaveChangesAsync();
                    justPaidNow = true;

                    Console.WriteLine($"[Confirm] justPaidNow TRUE → inst #{inst.Id} paid, amount={inst.Amount:N2}");
                }
                else
                {
                    Console.WriteLine($"[Confirm] installment #{inst.Id} was already paid earlier → no duplication.");
                }

                // 3) إشعار داخل الموقع (مرة واحدة)
                if (justPaidNow)
                {
                    var notifyTitle = "Ödeme Onayı";
                    var notifyMsg = $"#{inst.Id} numaralı taksit ödemeniz alındı.";

                    var exists = await _notifService.ExistsSimilarAsync(
                        payment.Enrollment.UserId, notifyTitle, notifyMsg, payment.Id, inst.Id);

                    if (!exists)
                    {
                        await _notifService.AddAsync(new Notification
                        {
                            UserId = payment.Enrollment.UserId,
                            Title = notifyTitle,
                            Message = notifyMsg,
                            PaymentId = payment.Id,
                            InstallmentId = inst.Id,
                            CreatedAt = DateTime.Now,
                            IsRead = false,
                            LinkUrl = Url.Action(nameof(Details), "Payment",
                                             new { id = payment.Id }, Request.Scheme)
                        });

                        Console.WriteLine($"[Confirm] site notification added for user #{payment.Enrollment.UserId}");
                    }
                    else
                    {
                        Console.WriteLine($"[Confirm] site notification already exists → skipped.");
                    }
                }

                // 4) إرسال الإيميل (فقط إذا تم الدفع الآن لتفادي التكرار)
                if (justPaidNow)
                {
                    var user = payment.Enrollment?.User;
                    if (user != null && !string.IsNullOrWhiteSpace(user.Email))
                    {
                        var displayName = !string.IsNullOrWhiteSpace(user.Username)
                            ? user.Username
                            : (user.Email.Split('@').FirstOrDefault() ?? "öğrenci");

                        var link = Url.Action(nameof(Details), "Payment", new { id = payment.Id }, Request.Scheme);

                        try
                        {
                            Console.WriteLine($"[EMAIL] Trying to send to {user.Email} (inst #{inst.Id})...");
                            await _email.SendAsync(
                                user.Email,
                                "Ödeme Onayı",
                                $"Merhaba {displayName},<br/>" +
                                $"#{inst.Id} numaralı taksit ödemeniz başarıyla alındı.<br/>" +
                                $"Tutar: {inst.Amount:N2} ₺<br/>" +
                                $"Detaylar: <a href=\"{link}\">Ödeme Detayı</a>"
                            );
                            Console.WriteLine($"[EMAIL] Sent OK → {user.Email}");

                            // (اختياري) نسخة للأدمن
                            var courseTitle = payment.Enrollment?.Course?.Title ?? "(kurs)";
                            await _email.SendAsync(
                                "admin@yourdomain.com",
                                "Yeni Ödeme",
                                $"Kullanıcı: {user.Email}<br/>Kurs: {courseTitle}<br/>" +
                                $"Taksit: #{inst.Id} – {inst.Amount:N2} ₺ alındı."
                            );
                        }
                        catch (Exception ex)
                        {
                            // لا نفشل الطلب بسبب الإيميل
                            Console.WriteLine("[EMAIL] FAILED from ConfirmPayment: " + ex.Message);
                            Console.WriteLine(ex.ToString());
                        }
                    }
                    else
                    {
                        Console.WriteLine("[EMAIL] skipped: user has no email.");
                    }
                }

                TempData["Ok"] = "Ödeme başarıyla alındı.";
            }
            else
            {
                TempData["Info"] = "Ödeme iptal edildi veya başarısız oldu.";
            }

            return RedirectToAction(nameof(Details), new { id = inst.PaymentId });
        }





    }
}



    

