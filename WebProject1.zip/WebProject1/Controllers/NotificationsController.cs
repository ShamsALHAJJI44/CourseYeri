﻿using Microsoft.AspNetCore.Mvc;
using WebProject1.Services;
using WebProject1.Models;
using WebProject1.Data;
using Microsoft.EntityFrameworkCore;

namespace WebProject1.Controllers
{
   // [Route("[controller]")]
    public class NotificationsController : Controller
    {
        private readonly ApplicationDbContext _ctx;
        private readonly INotificationService _svc;
        public NotificationsController(ApplicationDbContext ctx, INotificationService notif)
        {
            _ctx = ctx; _svc = notif;
        }
        [HttpGet]
        public async Task<IActionResult> Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId is null) return RedirectToAction("Login", "UserAccount");

            var list = await _svc.GetUserNotificationsAsync(userId.Value, 200);
            return View(list);
        }

        [HttpPost()]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkRead(int id)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId is null) return RedirectToAction("Login", "UserAccount");

            await _svc.MarkAsReadAsync(id, userId.Value);
            return RedirectToAction(nameof(Index));
        }

        [HttpPost()]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkAll()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId is null) return RedirectToAction("Login", "UserAccount");

            await _svc.MarkAllAsReadAsync(userId.Value);
            return RedirectToAction(nameof(Index));
        }
        [HttpGet()]
        public async Task<IActionResult> Count()
        {
            var uid = HttpContext.Session.GetInt32("UserId");
            if (uid is null) return Json(new { count = 0 });

            var c = await _svc.GetUnreadCountAsync(uid.Value);
            return Json(new { count = c });
        }




        [HttpGet()]
        public async Task<IActionResult> Add(int userId = 1)
        {
            await _svc.AddAsync(new Notification
            {
                UserId = userId,
                Title = "Test Bildirimi",
                Message = "Bu bir test bildirimidir.",
                CreatedAt = DateTime.Now,
                IsRead = false
            });
            return Content("OK");
        }
    }

}
