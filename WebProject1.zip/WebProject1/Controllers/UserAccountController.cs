﻿using Microsoft.AspNetCore.Mvc;
using WebProject1.Data;
using WebProject1.Models;

namespace WebProject1.Controllers
{
   // [Route("User")]
    public class UserAccountController : Controller
    {
        private readonly ApplicationDbContext _context;
        public UserAccountController(ApplicationDbContext context) => _context = context;

        [HttpGet]
        public IActionResult Login(string? returnUrl = null)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View(new LoginVM());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Login(LoginVM model, string? returnUrl = null)
        {
            if (!ModelState.IsValid) return View(model);

            var user = _context.Users.FirstOrDefault(u =>
                u.Username == model.Username &&
                u.Password == model.Password &&
                u.Role.ToLower() == "user");

            if (user == null)
            {
                ModelState.AddModelError("", "Kullanıcı adı veya şifre hatalı.");
                return View(model);
            }

            HttpContext.Session.SetString("Username", user.Username);
            HttpContext.Session.SetInt32("UserId", user.Id);
            HttpContext.Session.SetString("Role", "user");

            if (!string.IsNullOrWhiteSpace(returnUrl))
                return Redirect(returnUrl);

            return RedirectToAction("Index", "UserHome");
        }


        [HttpGet()]
        public IActionResult Register() => View(new RegisterVM());

        [HttpPost()]
        [ValidateAntiForgeryToken]
        public IActionResult Register(RegisterVM model)
        {
            if (!ModelState.IsValid)
                return View(model);

            // فحوصات تفرد
            if (_context.Users.Any(u => u.Username == model.Username))
                ModelState.AddModelError("Username", "Bu kullanıcı adı zaten mevcut.");

            if (_context.Users.Any(u => u.Email == model.Email))
                ModelState.AddModelError("Email", "Bu email zaten kayıtlı.");

            if (!ModelState.IsValid)
                return View(model);

            var user = new User
            {
                Name = model.Name,
                Username = model.Username,
                Email = model.Email,
                Password = model.Password, // لاحقاً: Hash
                Role = "user",
                CreatedAt = DateTime.Now
            };

            _context.Users.Add(user);
            _context.SaveChanges();

            // تسجيل دخول تلقائي بعد التسجيل (اختياري)
            HttpContext.Session.SetString("Username", user.Username);
            HttpContext.Session.SetInt32("UserId", user.Id);
            HttpContext.Session.SetString("Role", "user");

            return RedirectToAction("Index", "UserHome");
        }

        [HttpGet()]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
