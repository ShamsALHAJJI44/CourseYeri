﻿// Controllers/TestController.cs
using Microsoft.AspNetCore.Mvc;
using WebProject1.Services;


public class TestController : Controller
{
    private readonly IEmailSender _email;
    public TestController(IEmailSender email) => _email = email;

    public async Task<IActionResult> SendTest()
    {
        await _email.SendAsync("engshams021@gmail.com", "Test Email",
            "<b>Merhaba!</b> Bu bir test mailidir.");
        return Content("Test mail tetiklendi. Log penceresine bak.");
    }
}

