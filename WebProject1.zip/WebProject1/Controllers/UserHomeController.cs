﻿using System.Linq;
using System.Security.Policy;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using WebProject1.Attributes;
using WebProject1.Data;
using WebProject1.Models;
using WebProject1.Models.Enums;
using WebProject1.Models.ViewModels;
using WebProject1.ViewModels;


namespace WebProject1.Controllers
{
    public class UserHomeController : Controller
    {
        private readonly ApplicationDbContext _ctx;
        private readonly IMemoryCache _cache;
        public UserHomeController(ApplicationDbContext ctx, IMemoryCache cache)
        {
            _ctx = ctx; _cache = cache;
        }
        [AllowAnonymous]
        public async Task<IActionResult> Home()
        {
            // تصنيفات مختصرة (badges)
            ViewBag.Categories = await _ctx.Categories
                .AsNoTracking()
                .OrderBy(c => c.Name)
                .Take(12)
                .Select(c => new { c.Id, c.Name })
                .ToListAsync();

            // آخر الدورات (لشريط أفقي)
            var latest = await _ctx.Courses
                .AsNoTracking()
                .Include(c => c.Category)
                .OrderByDescending(c => c.Id)
                .Take(12)
                .Select(c => new WebProject1.ViewModels.CourseCardVm
                {
                    Id = c.Id,
                    Title = c.Title,
                    CategoryName = c.Category != null ? c.Category.Name : null,
                    ThumbnailUrl = c.ImagePath,
                    Price = c.Price
                })
                .ToListAsync();

            return View(latest); // View: Views/UserHome/Home.cshtml
        }
        [AllowAnonymous]
        public async Task<IActionResult> Index(string q = "", int? categoryId = null, int page = 1, bool favoritesOnly = false)
        {
            page = Math.Max(1, page);

            // ... تعبئة ViewBag.CatFilter و ViewBag.Categories كما عندك ...

            var s = string.IsNullOrWhiteSpace(q) ? null : q.Trim();
            var vm = await BuildListVm(s, categoryId, page, favoritesOnly);

            ViewBag.Query = vm.Search;
            ViewBag.SelectedCategoryId = vm.CategoryId;
            ViewBag.FavoritesOnly = favoritesOnly;

            // مــهــم: رجّعي الـVM كامل، لا ترجّعي Items
            return View(vm);
        }

        [HttpGet, AllowAnonymous]
        [ResponseCache(Duration = 60, VaryByQueryKeys = new[] { "search", "q", "categoryId", "page", "favoritesOnly" })]
        public async Task<IActionResult> List(string? search, string? q, int? categoryId, int page = 1, bool favoritesOnly = false)
        {
            page = Math.Max(1, page);
            var s = !string.IsNullOrWhiteSpace(search) ? search.Trim()
                    : !string.IsNullOrWhiteSpace(q) ? q!.Trim()
                    : null;

            var vm = await BuildListVm(s, categoryId, page, favoritesOnly);

            // لأن الـPartial يستقبل القائمة فقط:
            return PartialView("_CourseList", vm.Items);

            // لو كنتِ مصممة الـPartial يستقبل الـVM كامل، بدّلي السطر السابق إلى:
            // return PartialView("_CourseList", vm);
        }


        // ==============
        // دالة مساعدة لبناء الـVM
        // ==============
        private async Task<PagedCoursesVm> BuildListVm(string? search, int? categoryId, int page, bool favoritesOnly = false)
        {
            const int pageSize = 12;

            var q = _ctx.Courses
                .AsNoTracking()
                .Include(c => c.Category)
                .AsQueryable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                q = q.Where(c =>
                    (c.Title ?? "").Contains(search) ||
                    (c.Description ?? "").Contains(search));
            }

            if (categoryId.HasValue)
            {
                q = q.Where(c => c.CategoryId == categoryId.Value);
            }

            var total = await q.CountAsync();

            var userId = HttpContext.Session.GetInt32("UserId");
            var favIds = userId == null
                ? new HashSet<int>()
                : _ctx.Favorites.Where(f => f.UserId == userId).Select(f => f.CourseId).ToHashSet();

            if (favoritesOnly && userId != null)
            {
                q = q.Where(c => _ctx.Favorites.Any(f => f.UserId == userId && f.CourseId == c.Id));
            }
            // ما عندك CreatedAt؛ منرتّب بالأحدث عبر Id
            var items = await q
                .OrderByDescending(c => c.Id)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .Select(c => new CourseCardVm
                {
                    Id = c.Id,
                    Title = c.Title,
                    CategoryName = c.Category != null ? c.Category.Name : null,
                    // عندك ImagePath في الموديل => نمرّرها كـ ThumbnailUrl للكرت
                    ThumbnailUrl = c.ImagePath,
                    Price = c.Price,

                   IsFavorite = favIds.Contains(c.Id)

                })
                .ToListAsync();

            return new PagedCoursesVm
            {
                Items = items,
                Page = page,
                PageSize = pageSize,
                HasNext = page * pageSize < total,
                TotalCount = total,
                Search = search,
                CategoryId = categoryId
            };
        }

        // =========================
        // باقي الأكشنات كما هي (بدون تغيير)
        // =========================

        // ALL Categories
        [AllowAnonymous]
        public IActionResult Categories()
        {
            var cats = _ctx.Categories
                           .OrderBy(c => c.Name)
                           .ToList();
            return View(cats);
        }

        // Courses by Category
        [AllowAnonymous]
        public IActionResult CategoryCourses(int id)
        {
            var cat = _ctx.Categories.Find(id);
            if (cat == null) return NotFound();

            var courses = _ctx.Courses
                              .Include(c => c.Category)
                              .Where(c => c.CategoryId == id)
                              .OrderByDescending(c => c.Id)
                              .ToList();

            ViewBag.Category = cat;
            return View(courses);
        }

        // My Courses (enrollments of current user)
        [UserOnly]
        public IActionResult MyCourses()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                return RedirectToAction("Login", "UserAccount", new
                {
                    returnUrl = Url.Action(nameof(MyCourses), "UserHome")
                });
            }

            var enrollments = _ctx.Enrollments
                .Include(e => e.Course).ThenInclude(c => c.Category)
                .Where(e => e.UserId == userId)
                .OrderByDescending(e => e.EnrollmentDate)
                .ToList();

            var vms = enrollments.Select(e => new MyCourseVM
            {
                CourseId = e.CourseId,
                Title = e.Course?.Title,
                ImagePath = e.Course?.ImagePath,
                Description = e.Course?.Description,
                Duration = e.Course?.Duration,
                CategoryName = e.Course?.Category?.Name,
                EnrollmentDate = e.EnrollmentDate,
                PaymentStatus = e.PaymentStatus
            }).ToList();

            return View(vms);
        }

        // Enroll to a course (from user side)
        [UserOnly]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Enroll(int courseId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
            {
                var ret = Url.Action("CourseDetails", "UserHome", new { id = courseId });
                return RedirectToAction("Login", "UserAccount", new { returnUrl = ret });
            }

            bool exists = _ctx.Enrollments.Any(e => e.UserId == userId && e.CourseId == courseId);
            if (!exists)
            {
                _ctx.Enrollments.Add(new Enrollment
                {
                    UserId = userId.Value,
                    CourseId = courseId,
                    EnrollmentDate = DateTime.Now
                });
                _ctx.SaveChanges();
                TempData["EnrollOk"] = "Kursa kaydınız oluşturuldu.";
            }
            else
            {
                TempData["EnrollOk"] = "Zaten bu kursa kayıtlısınız.";
            }

            return RedirectToAction("MyCourses");
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Unenroll(int courseId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "UserAccount");

            var enr = _ctx.Enrollments
                          .FirstOrDefault(e => e.UserId == userId && e.CourseId == courseId);

            if (enr == null)
            {
                TempData["UnenrollErr"] = "Kayıt bulunamadı veya yetkiniz yok.";
                return RedirectToAction("MyCourses");
            }

            _ctx.Enrollments.Remove(enr);
            _ctx.SaveChanges();
            TempData["UnenrollOk"] = "Kayıt başarıyla silindi.";
            return RedirectToAction("MyCourses");
        }

        [AllowAnonymous]
        public async Task<IActionResult> CourseDetails(int id)
        {
           
            var course = await _ctx.Courses
                .AsNoTracking()
                .Include(c => c.Category)
                .FirstOrDefaultAsync(c => c.Id == id);

            if (course == null) return NotFound();

            
            double? avg = await _ctx.Reviews
                .Where(r => r.CourseId == id)
                .Select(r => (double?)r.Stars)
                .AverageAsync();

            ViewBag.AvgStars = Math.Round((decimal)(avg ?? 0d), 1);

            
            const string key = "rv";
            var raw = Request.Cookies[key];
            var ids = string.IsNullOrWhiteSpace(raw)
                ? new List<int>()
                : raw.Split(',').Select(s => int.TryParse(s, out var x) ? x : -1)
                      .Where(x => x > 0).ToList();

            ids.Remove(id); ids.Insert(0, id);
            if (ids.Count > 6) ids = ids.Take(6).ToList();

            Response.Cookies.Append(key, string.Join(",", ids),
                new CookieOptions { Expires = DateTimeOffset.UtcNow.AddDays(7) });


            var reviews = await _ctx.Reviews
.Where(r => r.CourseId == id)
.OrderByDescending(r => r.CreatedAt)
.Take(10)
.ToListAsync();
            ViewBag.Reviews = reviews;
 

            return View(course); // CourseDetails.cshtml
        }

        [AllowAnonymous]
        public IActionResult About() => View();

        [AllowAnonymous]
        [HttpGet]
        public IActionResult Contact()
        {
            return View(new WebProject1.Models.ContactVM());
        }

        [AllowAnonymous]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Contact(ContactVM model)
        {
            if (!ModelState.IsValid) return View(model);

            _ctx.ContactMessages.Add(new ContactMessage
            {
                Name = model.Name,
                Email = model.Email,
                Message = model.Message
            });
            _ctx.SaveChanges();

            TempData["ContactOk"] = "Mesajınız alındı. En kısa sürede sizinle iletişime geçeceğiz.";
            return RedirectToAction(nameof(Contact));
        }

        // GET: Course/SelectType/{id}
        public IActionResult SelectType(int id)
        {
            ViewBag.CourseId = id;
            return View();
        }

        [HttpPost]
        public IActionResult ConfirmType(int CourseId, string Type)
        {
            if (string.IsNullOrEmpty(Type))
            {
                TempData["Error"] = "Lütfen kurs türünü seçiniz.";
                return RedirectToAction("SelectType", new { id = CourseId });
            }

            HttpContext.Session.SetString("SelectedCourseType", Type);
            HttpContext.Session.SetInt32("SelectedCourseId", CourseId);

            return RedirectToAction("Agreement", "Payment", new { courseId = CourseId });
        }

        public IActionResult Payments()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return RedirectToAction("Login", "UserAccount");

            var payments = _ctx.Payments
                .Include(p => p.Enrollment).ThenInclude(e => e.Course)
                .Include(p => p.Installments)
                .Where(p => p.Enrollment.UserId == userId)
                .OrderByDescending(p => p.CreatedAt)
                .ToList();

            var today = DateTime.Today;
            var soon = today.AddDays(3);

            var overdueCount = payments
                .SelectMany(p => p.Installments ?? new List<PaymentInstallment>())
                .Count(i => !i.IsPaid && i.DueDate.Date < today);

            var dueSoon = payments
                .SelectMany(p => p.Installments ?? new List<PaymentInstallment>())
                .Where(i => !i.IsPaid && i.DueDate.Date >= today && i.DueDate.Date <= soon)
                .OrderBy(i => i.DueDate)
                .ToList();

            ViewBag.OverdueCount = overdueCount;
            ViewBag.DueSoon = dueSoon;

            return View(payments);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult MockPayInstallment(int installmentId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "UserAccount");

            var inst = _ctx.PaymentInstallments
                .Include(i => i.Payment).ThenInclude(p => p.Enrollment)
                .FirstOrDefault(i => i.Id == installmentId);

            if (inst == null || inst.Payment.Enrollment.UserId != userId)
            {
                TempData["PaymentOk"] = "Hatalı istek.";
                return RedirectToAction("Payments");
            }

            if (!inst.IsPaid)
            {
                inst.IsPaid = true;
                inst.PaidAt = DateTime.Now;

                var payment = inst.Payment;
                var allPaid = _ctx.PaymentInstallments.Where(x => x.PaymentId == payment.Id).All(x => x.IsPaid);
                if (allPaid)
                {
                    payment.Status = PaymentStatus.PaidFull;
                    payment.Enrollment.PaymentStatus = PaymentStatus.PaidFull;
                }

                _ctx.SaveChanges();
                TempData["PaymentOk"] = "Taksit ödendi (mock).";
            }

            return RedirectToAction("Payments");
        }
        [HttpPost]
        public async Task<IActionResult> FavoriteToggle(int courseId)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null)
                return Unauthorized(new { ok = false, msg = "login-required" });

            // بما أننا عرّفنا مفتاح مركب (UserId, CourseId) نقدر نستعمل FindAsync:
            var fav = await _ctx.Favorites.FindAsync(userId.Value, courseId);

            bool isFav;
            if (fav == null)
            {
                _ctx.Favorites.Add(new Favorite { UserId = userId.Value, CourseId = courseId });
                isFav = true;
            }
            else
            {
                _ctx.Favorites.Remove(fav);
                isFav = false;
            }

            await _ctx.SaveChangesAsync();
            return Json(new { ok = true, isFav });
        }
        [AllowAnonymous]
        public async Task<IActionResult> Quick(int id)
        {
            var c = await _ctx.Courses.AsNoTracking().Include(x => x.Category).FirstOrDefaultAsync(x => x.Id == id);
            if (c == null) return NotFound();
            var vm = new CourseQuickVm
            {
                Id = c.Id,
                Title = c.Title,
                Category = c.Category?.Name,
                Price = c.Price,
                Image = c.ImagePath,
                Duration = c.Duration,
                Description = c.Description
            };
            return PartialView("_QuickCourse", vm);
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PostReview(Review r)
        {
            var uid = HttpContext.Session.GetInt32("UserId");
            if (uid == null) return RedirectToAction("Login", "User");
            r.UserId = uid.Value;
            if (!ModelState.IsValid) return RedirectToAction("CourseDetails", new { id = r.CourseId });
            _ctx.Reviews.Add(r);
            await _ctx.SaveChangesAsync();
            TempData["ReviewOk"] = "Değerlendirmen kaydedildi. Teşekkürler!";
            return RedirectToAction("CourseDetails", new { id = r.CourseId });

            
        }

    }
}

