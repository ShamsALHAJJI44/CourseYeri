﻿using Microsoft.AspNetCore.Mvc;
using WebProject1.Data;
using WebProject1.Models;
using WebProject1.Attributes; // لو عندك [UserOnly]
using Microsoft.EntityFrameworkCore;

namespace WebProject1.Controllers
{
    [UserOnly] // تأكد مفعّل، أو احذفه لو ما عندك الفلتر
    //[Route("User/Profile")]
    public class UserProfileController : Controller
    {
        private readonly ApplicationDbContext _ctx;
        public UserProfileController(ApplicationDbContext ctx) => _ctx = ctx;

        [HttpGet()]
        public IActionResult Index()
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "UserAccount");

            var u = _ctx.Users.FirstOrDefault(x => x.Id == userId);
            if (u == null) return NotFound();

            var vm = new ProfileEditVM
            {
                Username = u.Username,
                Name = u.Name,
                Email = u.Email
            };
            return View(vm);
        }

        [HttpPost()]
        [ValidateAntiForgeryToken]
        public IActionResult Update(ProfileEditVM model)
        {
            var userId = HttpContext.Session.GetInt32("UserId");
            if (userId == null) return RedirectToAction("Login", "UserAccount");

            if (!ModelState.IsValid)
                return View("Index", model);

            var u = _ctx.Users.FirstOrDefault(x => x.Id == userId);
            if (u == null) return NotFound();

            // تحديث الاسم والإيميل دائماً
            u.Name = model.Name.Trim();
            u.Email = model.Email.Trim();

            // تغيير كلمة المرور (اختياري): لو المستخدم أدخل NewPassword
            if (!string.IsNullOrWhiteSpace(model.NewPassword))
            {
                // تأكد من إدخال القديم ومطابقته
                if (string.IsNullOrWhiteSpace(model.OldPassword) || u.Password != model.OldPassword)
                {
                    ModelState.AddModelError(nameof(model.OldPassword), "Eski şifre hatalı.");
                    return View("Index", model);
                }
                // (لاحقاً: استبدال التخزين النصّي بالـ Hash)
                u.Password = model.NewPassword;
            }

            _ctx.SaveChanges();
            TempData["ProfileOk"] = "Profil bilgileri güncellendi.";
            return RedirectToAction("Index");
        }
        

    }
}
