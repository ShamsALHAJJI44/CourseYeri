using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebProject1.Views.Shared
{
    public class _AuthLayoutModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
