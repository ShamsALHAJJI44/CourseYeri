﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;

namespace WebProject1.Attributes
{
    public class UserOnlyAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext ctx)
        {
            var role = ctx.HttpContext.Session.GetString("Role");
            if (string.IsNullOrEmpty(role) || role != "user")
                ctx.Result = new RedirectToActionResult("Login", "UserAuth", null);
            base.OnActionExecuting(ctx);
        }
    }
}
