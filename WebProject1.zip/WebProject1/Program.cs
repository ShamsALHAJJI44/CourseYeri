﻿using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Models;
using WebProject1.Services;

// ADD: Response Compression usings
using Microsoft.AspNetCore.ResponseCompression;
using System.IO.Compression;

namespace WebProject1
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // 1) Session
            builder.Services.AddDistributedMemoryCache();
            builder.Services.AddSession(o =>
            {
                o.IdleTimeout = TimeSpan.FromMinutes(60);
                o.Cookie.HttpOnly = true;
                o.Cookie.IsEssential = true;
            });

            // 2) MVC
            builder.Services.AddControllersWithViews();

            // 3) EF Core
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

            // 4) DI services
            builder.Services.AddScoped<INotificationService, NotificationService>();
            builder.Services.AddScoped<IEmailSender, SmtpEmailSender>();
            builder.Services.AddScoped<IInstallmentReminder, InstallmentReminder>();
            builder.Services.AddHostedService<InstallmentReminderService>();

            //  Response Compression services (Brotli + Gzip)
            builder.Services.AddResponseCompression(opts =>
            {
                opts.EnableForHttps = true;
                opts.Providers.Add<BrotliCompressionProvider>();
                opts.Providers.Add<GzipCompressionProvider>();
            });
            builder.Services.Configure<BrotliCompressionProviderOptions>(o => o.Level = CompressionLevel.Optimal);
            builder.Services.Configure<GzipCompressionProviderOptions>(o => o.Level = CompressionLevel.Optimal);

            var app = builder.Build();

            // 5) Error handling / HSTS
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                app.UseHsts();
            }

            // 6) DB migrate + seed admin
            using (var scope = app.Services.CreateScope())
            {
                var services = scope.ServiceProvider;
                var context = services.GetRequiredService<ApplicationDbContext>();

                context.Database.Migrate();

                if (!context.Users.Any(u => u.Username == "admin"))
                {
                    context.Users.Add(new User
                    {
                        Name = "Admin",
                        Username = "admin",
                        Email = "admin@example.com",
                        Password = "123456",            // لاحقًا تقدر تحوّلها Hash/Salt (الكود يدعم الإثنين)
                        Role = "admin",
                        CreatedAt = DateTime.Now
                    });
                    context.SaveChanges();
                }
            }

            // 7) Pipeline
            app.UseHttpsRedirection();

            // ADD: Enable response compression BEFORE static files/routing
            app.UseResponseCompression();

            // ADD: Static files with cache headers (كاش يوم كامل + immutable)
            app.UseStaticFiles(new StaticFileOptions
            {
                OnPrepareResponse = ctx =>
                {
                    // يطبق على ملفات wwwroot (css/js/img/…)
                    ctx.Context.Response.Headers["Cache-Control"] = "public,max-age=86400,immutable";
                }
            });

            app.UseStaticFiles();

            QuestPDF.Settings.License = QuestPDF.Infrastructure.LicenseType.Community;

            builder.Services.AddMemoryCache();
            app.UseRouting();

            app.UseSession();
            app.UseAuthorization();


            //app.MapControllerRoute(
            //    name: "admin_login_alias",
            //    pattern: "Admin/Account/{action=Login}/{id?}",
            //    defaults: new { controller = "Account" });

            app.MapControllerRoute(
                name: "areas",
                pattern: "{area:exists}/{controller=Dashboard}/{action=Index}/{id?}");

            app.MapControllerRoute(
             name: "default",
             pattern: "{controller=UserHome}/{action=Home}/{id?}");


            app.Run();
        }
    }
}
