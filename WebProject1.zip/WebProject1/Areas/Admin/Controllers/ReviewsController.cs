﻿using Azure.Core;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Models;
// using WebProject1.Attributes; // فعّليه لو عندك AdminOnly

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    // [AdminOnly] // اختياري إذا أنشأناه سابقاً
    public class ReviewsController : Controller
    {
        private readonly ApplicationDbContext _ctx;
        public ReviewsController(ApplicationDbContext ctx) => _ctx = ctx;

        // صفحة الجدول
        public IActionResult Index() => View();


[HttpPost]
    public async Task<IActionResult> GetData()
    {
        var draw = Request.Form["draw"].FirstOrDefault();
        var start = int.TryParse(Request.Form["start"].FirstOrDefault(), out var s) ? s : 0;
        var length = int.TryParse(Request.Form["length"].FirstOrDefault(), out var l) ? l : 10;
        var search = Request.Form["search[value]"].FirstOrDefault() ?? string.Empty;

        // ❶ عرّفي q كـ IQueryable<Review> (مو IIncludableQueryable)
        IQueryable<Review> q = _ctx.Reviews.AsNoTracking();

        // ❷ طبّقي الفلترة أولاً
        if (!string.IsNullOrWhiteSpace(search))
        {
            var like = search.Trim();
            q = q.Where(r =>
                (r.Comment ?? "").Contains(like) ||
                ((r.Course != null ? r.Course.Title : "") ?? "").Contains(like)   // أو r.Course!.Title
            );
            // ملاحظة: لو بدك بحث غير حسّاس لحالة الأحرف:
            // q = q.Where(r => EF.Functions.Like(r.Comment ?? "", $"%{like}%")
            //               || EF.Functions.Like(r.Course!.Title ?? "", $"%{like}%"));
        }

        var total = await q.CountAsync();

        // ❸ بعد الفلترة، أدرج الـCourse للعرض فقط
        var data = await q
            .Include(r => r.Course)
            .OrderByDescending(r => r.CreatedAt)
            .Skip(start).Take(length)
            .Select(r => new {
                r.Id,
                Course = r.Course!.Title,
                r.Stars,
                r.Comment,
                CreatedAt = r.CreatedAt.ToString("yyyy-MM-dd HH:mm")
            })
            .ToListAsync();

        return Json(new
        {
            draw,
            recordsTotal = total,
            recordsFiltered = total,
            data
        });
    }

    // حذف مراجعة
    [HttpPost]
        public async Task<IActionResult> Delete(int id)
        {
            var r = await _ctx.Reviews.FindAsync(id);
            if (r != null)
            {
                _ctx.Reviews.Remove(r);
                await _ctx.SaveChangesAsync();
            }
            return Json(new { ok = true });
        }
    }
}

