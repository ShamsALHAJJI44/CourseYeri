﻿using System;
using ClosedXML.Excel;
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.InkML;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Elements.Table;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using WebProject1.Data;
using WebProject1.Filters;
using WebProject1.Models;
using Xceed.Pdf;
// حلّ التعارض بين Document تبع QuestPDF و Word
using Document = QuestPDF.Fluent.Document;
using W = DocumentFormat.OpenXml.Wordprocessing;





namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class EnrollmentsController : AdminBaseController
    {
        private readonly ApplicationDbContext _context;

        public EnrollmentsController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Enrollments
        [HttpGet]
        public async Task<IActionResult> Index(string? search, int page = 1, int pageSize = 10)
        {
            var q = _context.Enrollments
                .Include(e => e.User)
                .Include(e => e.Course)
                .AsQueryable();

            string s = (search ?? "").Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(e =>
                    e.User != null && (
                        (e.User.Name ?? "").ToLower().Contains(s) ||
                        (e.User.Username ?? "").ToLower().Contains(s) ||
                        (e.User.Email ?? "").ToLower().Contains(s)
                    )
                    ||
                    e.Course != null && (e.Course.Title ?? "").ToLower().Contains(s)
                );
            }


            var totalCount = await q.CountAsync();
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            if (page < 1) page = 1;
            if (totalPages > 0 && page > totalPages) page = totalPages;

            var list = await q
                .OrderByDescending(e => e.EnrollmentDate)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.Search = search;
            ViewBag.Page = page;
            ViewBag.TotalPages = totalPages;

            return View(list);
        }



        // GET: Enrollment/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollment = await _context.Enrollments
                .Include(e => e.Course)
                .Include(e => e.User)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (enrollment == null)
            {
                return NotFound();
            }

            return View(enrollment);
        }


        // GET: Enrollments/Create
        public IActionResult Create()
        {
            ViewBag.Users = new SelectList(_context.Users.ToList(), "Id", "Name");
            ViewBag.Courses = new SelectList(_context.Courses.ToList(), "Id", "Title");
            return View();
        }

        // POST: Enrollments/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Enrollment enrollment)
        {
            if (!ModelState.IsValid)
            {
                ViewBag.Users = new SelectList(_context.Users.ToList(), "Id", "Name", enrollment.UserId);
                ViewBag.Courses = new SelectList(_context.Courses.ToList(), "Id", "Title", enrollment.CourseId);
                return View(enrollment);
            }

            // منع التسجيل المكرر (اختياري)
            var exists = await _context.Enrollments
                .AnyAsync(e => e.UserId == enrollment.UserId && e.CourseId == enrollment.CourseId);
            if (exists)
            {
                ModelState.AddModelError("", "Kullanıcı bu kursa zaten kayıtlı.");
                ViewBag.Users = new SelectList(_context.Users.ToList(), "Id", "Name", enrollment.UserId);
                ViewBag.Courses = new SelectList(_context.Courses.ToList(), "Id", "Title", enrollment.CourseId);
                return View(enrollment);
            }

            _context.Enrollments.Add(enrollment);
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        // GET: Enrollments/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollment = await _context.Enrollments.FindAsync(id);
            if (enrollment == null)
            {
                return NotFound();
            }

            ViewData["UserId"] = new SelectList(_context.Users, "Id", "Name", enrollment.UserId);
            ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Title", enrollment.CourseId);
            return View(enrollment);
        }


        // POST: Enrollments/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,UserId,CourseId,EnrollmentDate")] Enrollment enrollment)
        {
            if (id != enrollment.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(enrollment);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!_context.Enrollments.Any(e => e.Id == enrollment.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            ViewData["UserId"] = new SelectList(_context.Users, "Id", "Name", enrollment.UserId);
            ViewData["CourseId"] = new SelectList(_context.Courses, "Id", "Title", enrollment.CourseId);
            return View(enrollment);
        }

        // GET: Enrollment/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var enrollment = await _context.Enrollments
                .Include(e => e.Course)
                .Include(e => e.User)
                .FirstOrDefaultAsync(m => m.Id == id);

            if (enrollment == null)
            {
                return NotFound();
            }

            return View(enrollment);
        }

        // POST: Enrollment/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var enrollment = await _context.Enrollments.FindAsync(id);
            if (enrollment != null)
            {
                _context.Enrollments.Remove(enrollment);
                await _context.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpGet("ExportToExcel")]
        [Route("[area]/[controller]/[action]")]
        public async Task<IActionResult> ExportToExcel(string? search = null)
        {
            var q = _context.Enrollments
                .AsNoTracking()
                .Include(e => e.User)
                .Include(e => e.Course)
                .AsQueryable();

            var s = (search ?? string.Empty).Trim().ToLower();

            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(e =>
                    (e.User != null && (
                         (e.User.Name ?? "").ToLower().Contains(s) ||
                         (e.User.Username ?? "").ToLower().Contains(s) ||
                         (e.User.Email ?? "").ToLower().Contains(s)
                    ))
                    ||
                    (e.Course != null && (e.Course.Title ?? "").ToLower().Contains(s))
                );
            }

            var rows = await q
                .OrderByDescending(e => e.EnrollmentDate)
                .Select(e => new
                {
                    e.Id,
                    Ogrenci = e.User != null ? (e.User.Name ?? e.User.Username ?? "(yok)") : "(yok)",
                    Email = e.User != null ? (e.User.Email ?? "") : "",
                    Kurs = e.Course != null ? (e.Course.Title ?? "") : "",
                    KayitTarihi = e.EnrollmentDate
                })
                .ToListAsync();

            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Kayitlar");

            ws.Cell(1, 1).Value = "ID";
            ws.Cell(1, 2).Value = "Öğrenci";
            ws.Cell(1, 3).Value = "Email";
            ws.Cell(1, 4).Value = "Kurs";
            ws.Cell(1, 5).Value = "Kayıt Tarihi";

            var r = 2;
            foreach (var row in rows)
            {
                ws.Cell(r, 1).Value = row.Id;
                ws.Cell(r, 2).Value = row.Ogrenci;
                ws.Cell(r, 3).Value = row.Email;
                ws.Cell(r, 4).Value = row.Kurs;
                ws.Cell(r, 5).Value = row.KayitTarihi;
                ws.Cell(r, 5).Style.DateFormat.Format = "dd.MM.yyyy HH:mm";
                r++;
            }

            ws.Columns().AdjustToContents();

            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            ms.Position = 0;

            var fileName = $"Kayitlar_{DateTime.Now:yyyy-MM-dd_HH-mm}.xlsx";
            return File(ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }
        [HttpGet("ExportToPdf")]
        [Route("[area]/[controller]/[action]")]
        public async Task<IActionResult> ExportToPdf(string? search = null)
        {
            var q = _context.Enrollments
                .AsNoTracking()
                .Include(e => e.User)
                .Include(e => e.Course)
                .AsQueryable();

            var s = (search ?? "").Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(e =>
                    (e.User != null && (
                        (e.User.Name ?? "").ToLower().Contains(s) ||
                        (e.User.Username ?? "").ToLower().Contains(s) ||
                        (e.User.Email ?? "").ToLower().Contains(s)
                    ))
                    || (e.Course != null && (e.Course.Title ?? "").ToLower().Contains(s)));
            }

            var rows = await q
                .OrderByDescending(e => e.EnrollmentDate)
                .Select(e => new
                {
                    e.Id,
                    Ogrenci = e.User != null ? (e.User.Name ?? e.User.Username ?? "") : "",
                    Email = e.User != null ? (e.User.Email ?? "") : "",
                    Kurs = e.Course != null ? (e.Course.Title ?? "") : "",
                    KayitTarihi = e.EnrollmentDate
                })
                .ToListAsync();

            var pdfBytes = Document.Create(doc =>
            {
                doc.Page(p =>
                {
                    p.Size(PageSizes.A4);
                    p.Margin(20);
                    p.DefaultTextStyle(x => x.FontSize(11));

                    p.Header().Text("Kayıtlı Öğrenciler")
                              .SemiBold().FontSize(16).AlignCenter();

                    p.Content().Table(t =>
                    {
                        t.ColumnsDefinition(c =>
                        {
                            c.ConstantColumn(40); // ID
                            c.RelativeColumn(2);  // Öğrenci
                            c.RelativeColumn(3);  // Email
                            c.RelativeColumn(2);  // Kurs
                            c.RelativeColumn(2);  // Kayıt Tarihi
                        });

                        // Header
                        t.Header(h =>
                        {
                            HeaderCell(h.Cell(), "ID");
                            HeaderCell(h.Cell(), "Öğrenci");
                            HeaderCell(h.Cell(), "Email");
                            HeaderCell(h.Cell(), "Kurs");
                            HeaderCell(h.Cell(), "Kayıt Tarihi");
                        });

                        // Rows
                        foreach (var r in rows)
                        {
                            DataCell(t.Cell(), r.Id.ToString());
                            DataCell(t.Cell(), r.Ogrenci);
                            DataCell(t.Cell(), r.Email);
                            DataCell(t.Cell(), r.Kurs);
                            DataCell(t.Cell(), r.KayitTarihi.ToString("dd.MM.yyyy HH:mm"));
                        }
                    });

                    p.Footer().AlignRight().Text(DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
                });
            }).GeneratePdf();

            var fileName = $"Kayitlar_{DateTime.Now:yyyy-MM-dd_HH-mm}.pdf";
            return File(pdfBytes, "application/pdf", fileName);

            // ===== Helpers الصحيحة =====
            static void HeaderCell(ITableCellContainer cell, string text) =>
                cell.Element(HeaderStyle)
                    .Text(text).SemiBold().AlignCenter();

            static void DataCell(ITableCellContainer cell, string? text) =>
                cell.Element(RowStyle)
                    .Text(text ?? "");

            static IContainer HeaderStyle(IContainer c) =>
                c.Background(Colors.Grey.Lighten3)
                 .BorderBottom(1).BorderColor(Colors.Grey.Medium)
                 .PaddingVertical(6);

            static IContainer RowStyle(IContainer c) =>
                c.BorderBottom(1).BorderColor(Colors.Grey.Lighten2)
                 .PaddingVertical(4);
        }



        [HttpGet("ExportToWord")]
        [Route("[area]/[controller]/[action]")]
        public async Task<IActionResult> ExportToWord(string? search = null)
        {
            var q = _context.Enrollments
                .AsNoTracking()
                .Include(e => e.User)
                .Include(e => e.Course)
                .AsQueryable();

            var s = (search ?? string.Empty).Trim().ToLower();

            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(e =>
                    (e.User != null && (
                         (e.User.Name ?? "").ToLower().Contains(s) ||
                         (e.User.Username ?? "").ToLower().Contains(s) ||
                         (e.User.Email ?? "").ToLower().Contains(s)
                    ))
                    ||
                    (e.Course != null && (e.Course.Title ?? "").ToLower().Contains(s))
                );
            }

            // العناوين
            string[] headers = { "ID", "Öğrenci", "Email", "Kurs", "Kayıt Tarihi" };

            // صفوف البيانات (جاهزة للتمرير لـ BuildWordDocument)
            var rows = await q
                .OrderByDescending(e => e.EnrollmentDate)
                .Select(e => new[]
                {
            e.Id.ToString(),
            e.User != null ? (e.User.Name ?? e.User.Username ?? "") : "",
            e.User != null ? (e.User.Email ?? "") : "",
            e.Course != null ? (e.Course.Title ?? "") : "",
            e.EnrollmentDate.ToString("yyyy-MM-dd HH:mm")
                })
                .ToListAsync();

            var bytes = BuildWordDocument("Kayıtlı Öğrenciler", headers, rows);
            var fileName = $"Kayitlar_{DateTime.Now:yyyyMMdd_HHmm}.docx";

            return File(bytes,
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                fileName);
        }



        private static byte[] BuildWordDocument(string title, string[] headers, List<string[]> rows)
        {
            using var ms = new MemoryStream();

            using (var doc = WordprocessingDocument.Create(ms, WordprocessingDocumentType.Document, true))
            {
                var mainPart = doc.AddMainDocumentPart();
                mainPart.Document = new W.Document(new W.Body());
                var body = mainPart.Document.Body;

                // عنوان
                var titlePara = new Paragraph(
                    new Run(new Text(title))
                );
                titlePara.ParagraphProperties = new ParagraphProperties(
                    new Justification() { Val = JustificationValues.Center }
                );
                // تنسيق بسيط: Bold + حجم أكبر
                var rPr = new RunProperties(new Bold(), new FontSize() { Val = "28" }); // 14pt
                titlePara.Descendants<Run>().First().RunProperties = rPr;
                body.AppendChild(titlePara);
                body.AppendChild(new Paragraph(new Run(new Text(" ")))); // مسافة

                // جدول
                var table = new W.Table();

                // حدود الجدول
                var tblProps = new TableProperties(
                    new TableStyle() { Val = "TableGrid" },
                    new TableBorders(
                        new TopBorder() { Val = BorderValues.Single, Size = 6 },
                        new BottomBorder() { Val = BorderValues.Single, Size = 6 },
                        new LeftBorder() { Val = BorderValues.Single, Size = 6 },
                        new RightBorder() { Val = BorderValues.Single, Size = 6 },
                        new InsideHorizontalBorder() { Val = BorderValues.Single, Size = 6 },
                        new InsideVerticalBorder() { Val = BorderValues.Single, Size = 6 }
                    )
                );
                table.AppendChild(tblProps);

                // صف العناوين
                var headerRow = new TableRow();
                foreach (var h in headers)
                {
                    var cellPara = new Paragraph(new Run(new Text(h)));
                    // Bold للعناوين
                    cellPara.ParagraphProperties = new ParagraphProperties(
                        new Justification() { Val = JustificationValues.Center }
                    );
                    cellPara.GetFirstChild<Run>()!.RunProperties = new RunProperties(new Bold());

                    var cell = new TableCell(cellPara);
                    // padding بسيط
                    cell.Append(new TableCellProperties(new TableCellMargin(
                        new LeftMargin() { Width = "100", Type = TableWidthUnitValues.Dxa },
                        new RightMargin() { Width = "100", Type = TableWidthUnitValues.Dxa }
                    )));
                    headerRow.Append(cell);
                }
                table.Append(headerRow);

                // صفوف البيانات
                foreach (var row in rows)
                {
                    var tr = new TableRow();
                    foreach (var col in row)
                    {
                        var p = new Paragraph(new Run(new Text(col ?? string.Empty)));
                        var tc = new TableCell(p);
                        tc.Append(new TableCellProperties(new TableCellMargin(
                            new LeftMargin() { Width = "100", Type = TableWidthUnitValues.Dxa },
                            new RightMargin() { Width = "100", Type = TableWidthUnitValues.Dxa }
                        )));
                        tr.Append(tc);
                    }
                    table.Append(tr);
                }

                body.Append(table);
                mainPart.Document.Save();
            }

            return ms.ToArray();
        }
      

[HttpGet]
    public async Task<IActionResult> Data(string? q = null, DateTime? from = null, DateTime? to = null)
    {
        var dt = WebProject1.Infrastructure.DataTables.DataTablesRequest.From(Request, defaultOrderColumn: "EnrollmentDate");

        var src = _context.Enrollments
            .AsNoTracking()
            .Include(e => e.User)
            .Include(e => e.Course)
            .Select(e => new
            {
                e.Id,
                Student = e.User != null ? e.User.Name : "",
                Course = e.Course != null ? e.Course.Title : "",
                EnrollmentDate = e.EnrollmentDate
            });

        // فلاتر تاريخ اختيارية
        if (from.HasValue) src = src.Where(x => x.EnrollmentDate >= from.Value);
        if (to.HasValue) src = src.Where(x => x.EnrollmentDate < to.Value.AddDays(1));

        // بحث
        var search = dt.Search ?? q;
        if (!string.IsNullOrWhiteSpace(search))
            src = src.Where(x => x.Student.Contains(search) || x.Course.Contains(search));

        var total = await _context.Enrollments.CountAsync();
        var filtered = await src.CountAsync();

        // ترتيب
        src = dt.OrderColumn switch
        {
            "Student" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Student) : src.OrderBy(x => x.Student)),
            "Course" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Course) : src.OrderBy(x => x.Course)),
            "EnrollmentDate" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.EnrollmentDate) : src.OrderBy(x => x.EnrollmentDate)),
            _ => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.EnrollmentDate) : src.OrderBy(x => x.EnrollmentDate)),
        };

        var page = await src
            .Skip(dt.Start)
            .Take(dt.Length)
            .ToListAsync();

        return Json(new
        {
            draw = dt.Draw,
            recordsTotal = total,
            recordsFiltered = filtered,
            data = page
        });
    }

   

}
}


