﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Models.Enums;
using WebProject1.Models.ViewModels;
using WebProject1.Services;

namespace WebProject1.Areas.Admin.Controllers
{
    // /Admin/Notifications/...
    // [Route("Admin/Notifications")]
    [Area("Admin")]
    public class AdminNotificationsController : AdminBaseController
    {
        private readonly ApplicationDbContext _ctx;
        private readonly IInstallmentReminder _reminder;

        // ✅ كونستركتور صحيح يهيّئ كل الحقول
        public AdminNotificationsController(ApplicationDbContext ctx, IInstallmentReminder reminder)
        {
            _ctx = ctx;
            _reminder = reminder;
        }

        // GET: /Admin/Notifications
        [HttpGet()]
        public async Task<IActionResult> Index()
        {
            var list = await _ctx.Notifications
                .Where(n => n.IsForAdmin)
                .OrderBy(n => n.IsRead)               // غير المقروء أولاً
                .ThenByDescending(n => n.CreatedAt)   // الأحدث
                .ToListAsync();

            return View(list);
        }

        // POST: /Admin/Notifications/mark/{id}
        [HttpPost("mark/{id:int}")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkAsRead(int id)
        {
            var n = await _ctx.Notifications.FirstOrDefaultAsync(x => x.Id == id && x.IsForAdmin);
            if (n != null && !n.IsRead)
            {
                n.IsRead = true;
                await _ctx.SaveChangesAsync();
            }
            return RedirectToAction(nameof(Index));
        }

        // POST: /Admin/Notifications/mark-all
        [HttpPost()]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> MarkAllAsRead()
        {
            var notifs = await _ctx.Notifications
                .Where(x => x.IsForAdmin && !x.IsRead)
                .ToListAsync();

            foreach (var n in notifs) n.IsRead = true;
            await _ctx.SaveChangesAsync();

            return RedirectToAction(nameof(Index));
        }

        // GET: /Admin/Notifications/count  (لشِارة الجرس)
        [HttpGet]
        [Route("/Admin/AdminNotifications/Count")]
        [Route("/AdminNotifications/Count")]
        [ResponseCache(NoStore = true, Location = ResponseCacheLocation.None)]
        public async Task<IActionResult> Count([FromServices] INotificationService notif)
        {
            int adminId = HttpContext.Session.GetInt32("AdminId") ?? 0;

            var personal = adminId > 0 ? await notif.GetUnreadCountAsync(adminId) : 0;
            var broadcast = await _ctx.Notifications.CountAsync(n => !n.IsRead && n.IsForAdmin);

            return Json(new { count = personal + broadcast });
        }

        // تفاصيل دفع للأدمن
        // يقبل المسار النسبي ضمن البادئة:
        [HttpGet()]
        // ويقبل أيضاً المسار القديم المطلق إن احتجتيه:
        [HttpGet()]
        public async Task<IActionResult> PaymentDetails(int id)
        {
            var p = await _ctx.Payments
                .Include(x => x.Enrollment).ThenInclude(e => e.User)
                .Include(x => x.Enrollment).ThenInclude(e => e.Course)
                .Include(x => x.Installments)
                .FirstOrDefaultAsync(x => x.Id == id);

            if (p == null) return NotFound();

            var vm = new PaymentVM
            {
                Id = p.Id,
                CourseTitle = p.Enrollment?.Course?.Title ?? "",
                TotalAmount = p.TotalAmount,
                Method = p.Method == PaymentMethod.Full ? "Peşin" : "Taksit",
                Status = p.Status == PaymentStatus.PaidFull ? "Ödendi (Tam)"
                        : p.Status == PaymentStatus.InstallmentOngoing ? "Taksit (Devam Ediyor)"
                        : p.Status.ToString(),
                CreatedAt = p.CreatedAt
            };

            foreach (var ins in p.Installments.OrderBy(i => i.DueDate))
            {
                var overdue = !ins.IsPaid && ins.DueDate.Date < DateTime.Today;
                var dueSoon = !ins.IsPaid && !overdue && (ins.DueDate.Date - DateTime.Today).TotalDays <= 3;

                vm.Installments.Add(new PaymentInstallmentVM
                {
                    Id = ins.Id,
                    Amount = ins.Amount,
                    DueDate = ins.DueDate,
                    IsPaid = ins.IsPaid,
                    PaidAt = ins.PaidAt,
                    IsOverdue = overdue,
                    IsDueSoon = dueSoon
                });
            }

            return View("PaymentDetails", vm);
        }

        // GET: /Admin/Notifications/RunReminders  (زر تشغيل يدوي)
        [HttpGet()]
        public async Task<IActionResult> RunReminders()
        {
            await _reminder.CheckAndNotifyAsync();
            TempData["Ok"] = "Taksit hatırlatıcı çalıştırıldı.";
            return Redirect("/Admin/Notifications");
        }
    }
}

