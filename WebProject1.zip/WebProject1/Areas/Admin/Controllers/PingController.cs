﻿using Microsoft.AspNetCore.Mvc;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class PingController : Controller
    {
        // مسار مطلق، يتجاوز أي مشكلة بالراوت التقليدي
        [HttpGet("/admin/ping")]
        public IActionResult Ping() => Content("OK");
    }
}
