﻿using Microsoft.AspNetCore.Mvc;
using WebProject1.Services;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    public class AdminRemindersController : AdminBaseController
    {
        private readonly IInstallmentReminder _reminder;

        public AdminRemindersController(IInstallmentReminder reminder)
        {
            _reminder = reminder;
        }

        [HttpGet("Run")]
        public async Task<IActionResult> Run()
        {
            await _reminder.CheckAndNotifyAsync();
            return Content("Taksit kontrolü ve bildirimler çalıştırıldı.");
        }
    }
}
