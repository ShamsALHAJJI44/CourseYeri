﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Filters;
using WebProject1.Models.Dashboard;


namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class DashboardController : AdminBaseController
    {
        private readonly ApplicationDbContext _context;
        public DashboardController(ApplicationDbContext context) => _context = context;

        public IActionResult Index()
        {
            var vm = new DashboardVM
            {
                UsersCount = _context.Users.Count(),
                CoursesCount = _context.Courses.Count(),
                CategoriesCount = _context.Categories.Count(),
                EnrollmentsCount = _context.Enrollments.Count(),

                LatestUsers = _context.Users
                    .OrderByDescending(u => u.CreatedAt)
                    .Take(5).ToList(),

                LatestCourses = _context.Courses
                    .OrderByDescending(c => c.Id)
                    .Take(5).ToList(),

                LatestEnrollments = _context.Enrollments
                    .Include(e => e.User).Include(e => e.Course)
                    .OrderByDescending(e => e.EnrollmentDate)
                    .Take(5).ToList()
            };

            // Line: Enrollments last 12 months (حقيقي)
            var start = new DateTime(DateTime.UtcNow.Year, DateTime.UtcNow.Month, 1).AddMonths(-11);
            var grouped = _context.Enrollments
                .Where(e => e.EnrollmentDate >= start)
                .AsEnumerable()
                .GroupBy(e => new DateTime(e.EnrollmentDate.Year, e.EnrollmentDate.Month, 1))
                .ToDictionary(g => g.Key, g => g.Count());

            for (int i = 0; i < 12; i++)
            {
                var m = start.AddMonths(i);
                vm.MonthLabels.Add(m.ToString("MMM"));
                vm.EnrollmentsByMonth.Add(grouped.TryGetValue(m, out var v) ? v : 0);
            }

            // Donut: Top 3 courses by enrollments (حقيقي)
            var topCourses = _context.Enrollments
                .Include(e => e.Course)
                .GroupBy(e => e.Course!.Title)
                .Select(g => new { Title = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .Take(3)
                .ToList();

            vm.TopCoursesLabels = topCourses.Select(x => x.Title).ToList();
            vm.TopCoursesCounts = topCourses.Select(x => x.Count).ToList();

            // Category distribution: enrollments per category (Top 5) (حقيقي)
            var catAgg = _context.Enrollments
                .Include(e => e.Course)!.ThenInclude(c => c!.Category)
                .GroupBy(e => e.Course!.Category!.Name)
                .Select(g => new { Name = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count).Take(5)
                .ToList();

            var total = catAgg.Sum(x => x.Count);
            vm.CategoryDist = catAgg.Select(x => (x.Name, x.Count, total == 0 ? 0 : (int)Math.Round((double)x.Count * 100 / total))).ToList();

             return View(vm);
            
        }
    }
}

