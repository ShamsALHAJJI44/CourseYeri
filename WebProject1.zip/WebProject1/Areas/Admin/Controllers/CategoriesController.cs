﻿using Microsoft.AspNetCore.Mvc;
using WebProject1.Data;
using WebProject1.Filters;
using WebProject1.Models;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class CategoriesController : AdminBaseController
    {
        private readonly ApplicationDbContext _context;

        public CategoriesController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var categories = _context.Categories.ToList();
            return View(categories);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Category category)
        {
            

            if (ModelState.IsValid)
            {
                Console.WriteLine("✅ ModelState valid");
                _context.Categories.Add(category);
                _context.SaveChanges();
                TempData["toast"] = "İşlem başarıyla tamamlandı.";
                return RedirectToAction("Index");
            }
            Console.WriteLine("❌ ModelState invalid");
            foreach (var value in ModelState.Values)
            {
                foreach (var error in value.Errors)
                {
                    Console.WriteLine("Validation error: " + error.ErrorMessage);
                }
            }
            return View(category);
        }

        public IActionResult Edit(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null) return NotFound();
            return View(category);
        }

        [HttpPost]
        public IActionResult Edit(Category category)
        {
            if (ModelState.IsValid)
            {
                _context.Categories.Update(category);
                _context.SaveChanges();
                TempData["toast"] = "İşlem başarıyla tamamlandı.";
                return RedirectToAction("Index");
            }
            return View(category);
        }

        public IActionResult Delete(int id)
        {
            var category = _context.Categories.Find(id);
            if (category == null) return NotFound();
            return View(category); // يعرض صفحة Delete.cshtml
        }

        [HttpPost]
        public IActionResult Delete(Category category)
        {
            var existing = _context.Categories.Find(category.Id);
            if (existing == null) return NotFound();

            _context.Categories.Remove(existing);
            _context.SaveChanges();
            TempData["toast"] = "Kullanıcı silindi.";
            return RedirectToAction("Index");
        }

    }
}
