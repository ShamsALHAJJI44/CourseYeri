﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using ClosedXML.Excel;

using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;

using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

using WebProject1.Data;
using WebProject1.Filters;
using WebProject1.Models;
using WebProject1.Utils;
using QuestPDF.Elements.Table;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;

// لتفادي أي التباس بين QuestPDF.Document و OpenXml.Wordprocessing.Document
using W = DocumentFormat.OpenXml.Wordprocessing;
using Document = QuestPDF.Fluent.Document;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class UsersController : AdminBaseController
    {
        private readonly ApplicationDbContext _context;

        public UsersController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Users
        [HttpGet]
        public async Task<IActionResult> Index(string? search, int page = 1, int pageSize = 10)
        {
            var q = _context.Users.AsQueryable();

            // search (null-safety)
            string s = (search ?? "").Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(u =>
                    ((u.Name ?? "").ToLower().Contains(s)) ||
                    ((u.Username ?? "").ToLower().Contains(s)) ||
                    ((u.Email ?? "").ToLower().Contains(s)) ||
                    ((u.Role ?? "").ToLower().Contains(s))
                );
            }

            // paging
            var totalCount = await q.CountAsync();
            var totalPages = (int)Math.Ceiling(totalCount / (double)pageSize);
            if (page < 1) page = 1;
            if (totalPages > 0 && page > totalPages) page = totalPages;

            var list = await q
                .OrderByDescending(u => u.CreatedAt)
                .Skip((page - 1) * pageSize)
                .Take(pageSize)
                .ToListAsync();

            ViewBag.Search = s;
            ViewBag.Page = page;
            ViewBag.TotalPages = totalPages;

            return View(list);
        }

        // GET: Users/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FirstOrDefaultAsync(m => m.Id == id);
            if (user == null) return NotFound();

            return View(user);
        }

        // GET: Users/Create
        public IActionResult Create() => View();

        // POST: Users/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(User model, string plainPassword)
        {
            if (!ModelState.IsValid) return View(model);

            var (hash, salt) = PasswordHelper.Hash(plainPassword);
            model.PasswordHash = hash;
            model.PasswordSalt = salt;
            model.Password = null; // لا نخزن النصّ

            _context.Users.Add(model);
            _context.SaveChanges();
            TempData["toast"] = "İşlem başarıyla tamamlandı.";
            return RedirectToAction(nameof(Index));
        }

        // GET: Users/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FindAsync(id);
            if (user == null) return NotFound();

            return View(user);
        }

        // POST: Users/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Name,Username,Email,Password,Role")] User user)
        {
            // استثناء السجل الحالي من فحص التكرار
            if (_context.Users.Any(x => x.Username == user.Username && x.Id != id))
                ModelState.AddModelError("Username", "Bu kullanıcı adı zaten mevcut");
            if (_context.Users.Any(x => x.Email == user.Email && x.Id != id))
                ModelState.AddModelError("Email", "Bu email zaten kayıtlı");

            if (!ModelState.IsValid) return View(user);
            if (id != user.Id) return NotFound();

            try
            {
                _context.Update(user);
                await _context.SaveChangesAsync();
                TempData["toast"] = "İşlem başarıyla tamamlandı.";
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!_context.Users.Any(e => e.Id == user.Id))
                    return NotFound();
                throw;
            }

            return RedirectToAction(nameof(Index));
        }

        // GET: Users/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null) return NotFound();

            var user = await _context.Users.FirstOrDefaultAsync(m => m.Id == id);
            if (user == null) return NotFound();

            return View(user);
        }

        // POST: Users/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var user = await _context.Users.FindAsync(id);
            if (user != null) _context.Users.Remove(user);

            await _context.SaveChangesAsync();
            TempData["toast"] = "Kullanıcı silindi.";
            return RedirectToAction(nameof(Index));
        }

        private bool UserExists(int id) => _context.Users.Any(e => e.Id == id);

        // ====== Export Excel ======
        [HttpGet("ExportToExcel")]
        [Route("[area]/[controller]/[action]")] // يضمن /Admin/Users/ExportToExcel
        public async Task<IActionResult> ExportToExcel(string? search = null)
        {
            var q = _context.Users.AsQueryable();

            var s = (search ?? "").Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(u =>
                    ((u.Name ?? "").ToLower().Contains(s)) ||
                    ((u.Username ?? "").ToLower().Contains(s)) ||
                    ((u.Email ?? "").ToLower().Contains(s)) ||
                    ((u.Role ?? "").ToLower().Contains(s))
                );
            }

            var users = await q
                .OrderBy(u => u.Id)
                .Select(u => new
                {
                    u.Id,
                    AdSoyad = u.Name,
                    KullaniciAdi = u.Username,
                    u.Email,
                    Rol = u.Role,
                    KayitTarihi = u.CreatedAt
                })
                .ToListAsync();

            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Kullanicilar");

            // عناوين
            ws.Cell(1, 1).Value = "ID";
            ws.Cell(1, 2).Value = "Ad Soyad";
            ws.Cell(1, 3).Value = "Kullanıcı Adı";
            ws.Cell(1, 4).Value = "Email";
            ws.Cell(1, 5).Value = "Rol";
            ws.Cell(1, 6).Value = "Kayıt Tarihi";

            // صفوف
            var r = 2;
            foreach (var u in users)
            {
                ws.Cell(r, 1).Value = u.Id;
                ws.Cell(r, 2).Value = u.AdSoyad;
                ws.Cell(r, 3).Value = u.KullaniciAdi;
                ws.Cell(r, 4).Value = u.Email;
                ws.Cell(r, 5).Value = u.Rol;
                ws.Cell(r, 6).Value = u.KayitTarihi;
                ws.Cell(r, 6).Style.DateFormat.Format = "dd.MM.yyyy HH:mm";
                r++;
            }

            ws.Columns().AdjustToContents();

            using var ms = new MemoryStream();
            wb.SaveAs(ms);
            ms.Position = 0;

            var fileName = $"Kullanicilar_{DateTime.Now:yyyy-MM-dd_HH-mm}.xlsx";
            return File(ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                fileName);
        }

        // ====== Export Word ======
        [HttpGet("ExportToWord")]
        [Route("[area]/[controller]/[action]")] // يضمن /Admin/Users/ExportToWord
        public async Task<IActionResult> ExportToWord(string? search = null)
        {
            var q = _context.Users.AsQueryable();

            var s = (search ?? "").Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(u =>
                    ((u.Name ?? "").ToLower().Contains(s)) ||
                    ((u.Username ?? "").ToLower().Contains(s)) ||
                    ((u.Email ?? "").ToLower().Contains(s)) ||
                    ((u.Role ?? "").ToLower().Contains(s))
                );
            }

            var list = await q.OrderBy(u => u.Name).ToListAsync();

            string[] headers = { "ID", "Ad Soyad", "Kullanıcı Adı", "Email", "Rol" };
            var rows = list.Select(u => new[]
            {
                u.Id.ToString(),
                u.Name ?? "",
                u.Username ?? "",
                u.Email ?? "",
                u.Role ?? ""
            }).ToList();

            var bytes = BuildWordDocument("Kullanıcı Listesi", headers, rows);
            var fileName = $"Kullanicilar_{DateTime.Now:yyyyMMdd_HHmm}.docx";

            return File(bytes,
                "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                fileName);
        }

        // ====== Export PDF (QuestPDF) ======
        [HttpGet("ExportToPdf")]
        [Route("[area]/[controller]/[action]")]
        public async Task<IActionResult> ExportToPdf(string? search = null)
        {
            var q = _context.Users.AsNoTracking().AsQueryable();

            var s = (search ?? "").Trim().ToLower();
            if (!string.IsNullOrWhiteSpace(s))
            {
                q = q.Where(u =>
                    (u.Name ?? "").ToLower().Contains(s) ||
                    (u.Username ?? "").ToLower().Contains(s) ||
                    (u.Email ?? "").ToLower().Contains(s) ||
                    (u.Role ?? "").ToLower().Contains(s));
            }

            var rows = await q
                .OrderBy(u => u.Name)
                .Select(u => new
                {
                    u.Id,
                    AdSoyad = u.Name ?? "",
                    KullaniciAdi = u.Username ?? "",
                    Email = u.Email ?? "",
                    Rol = u.Role ?? "",
                    KayitTarihi = u.CreatedAt
                })
                .ToListAsync();

            var pdfBytes = Document.Create(doc =>
            {
                doc.Page(p =>
                {
                    p.Size(PageSizes.A4);
                    p.Margin(20);
                    p.DefaultTextStyle(x => x.FontSize(11));
                    p.Header().Text("Kullanıcı Listesi").SemiBold().FontSize(16).AlignCenter();

                    p.Content().Table(t =>
                    {
                        t.ColumnsDefinition(c =>
                        {
                            c.ConstantColumn(40);   // ID
                            c.RelativeColumn(2);    // Ad Soyad
                            c.RelativeColumn(2);    // Kullanıcı Adı
                            c.RelativeColumn(3);    // Email
                            c.RelativeColumn(1);    // Rol
                            c.RelativeColumn(2);    // Kayıt Tarihi
                        });

                        t.Header(h =>
                        {
                            HeaderCell(h.Cell(), "ID");
                            HeaderCell(h.Cell(), "Ad Soyad");
                            HeaderCell(h.Cell(), "Kullanıcı Adı");
                            HeaderCell(h.Cell(), "Email");
                            HeaderCell(h.Cell(), "Rol");
                            HeaderCell(h.Cell(), "Kayıt Tarihi");
                        });

                        foreach (var r in rows)
                        {
                            DataCell(t.Cell(), r.Id.ToString());
                            DataCell(t.Cell(), r.AdSoyad);
                            DataCell(t.Cell(), r.KullaniciAdi);
                            DataCell(t.Cell(), r.Email);
                            DataCell(t.Cell(), r.Rol);
                            DataCell(t.Cell(), r.KayitTarihi.ToString("dd.MM.yyyy HH:mm"));
                        }
                    });

                    p.Footer().AlignRight().Text(DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
                });
            }).GeneratePdf();

            var fileName = $"Kullanicilar_{DateTime.Now:yyyy-MM-dd_HH-mm}.pdf";
            return File(pdfBytes, "application/pdf", fileName);

            // ========== Helpers ==========
            static void HeaderCell(ITableCellContainer cell, string text) =>
                cell.Element(HeaderStyle).Text(text).SemiBold().AlignCenter();

            static void DataCell(ITableCellContainer cell, string? text) =>
                cell.Element(RowStyle).Text(text ?? "");

            static IContainer HeaderStyle(IContainer c) => c
                .Background(Colors.Grey.Lighten3)
                .BorderBottom(1).BorderColor(Colors.Grey.Medium)
                .PaddingVertical(6);

            static IContainer RowStyle(IContainer c) => c
                .BorderBottom(1).BorderColor(Colors.Grey.Lighten2)
                .PaddingVertical(4);
        }

        // ====== Remote validation ======
        [AcceptVerbs("Get", "Post")]
        public IActionResult CheckUsername(string username, int? id)
        {
            if (string.IsNullOrWhiteSpace(username)) return Json(true);
            var exists = _context.Users.Any(u => u.Username == username && (id == null || u.Id != id.Value));
            return Json(!exists);
        }

        [AcceptVerbs("Get", "Post")]
        public IActionResult CheckEmail(string email, int? id)
        {
            if (string.IsNullOrWhiteSpace(email)) return Json(true);
            var exists = _context.Users.Any(u => u.Email == email && (id == null || u.Id != id.Value));
            return Json(!exists);
        }

        // ====== Word helper (OpenXML) ======
        private static byte[] BuildWordDocument(string title, string[] headers, List<string[]> rows)
        {
            using var ms = new MemoryStream();

            using (var doc = WordprocessingDocument.Create(ms, WordprocessingDocumentType.Document, true))
            {
                var mainPart = doc.AddMainDocumentPart();
                mainPart.Document = new W.Document(new W.Body());

                var body = mainPart.Document.Body;

                // العنوان
                var titlePara = new W.Paragraph(new W.Run(new W.Text(title)));
                titlePara.ParagraphProperties = new W.ParagraphProperties(
                    new W.Justification() { Val = W.JustificationValues.Center });
                titlePara.Descendants<W.Run>().First().RunProperties =
                    new W.RunProperties(new W.Bold(), new W.FontSize() { Val = "28" }); // 14pt

                body.AppendChild(titlePara);
                body.AppendChild(new W.Paragraph(new W.Run(new W.Text(" ")))); // سطر فراغ

                // الجدول
                var table = new W.Table();

                // حدود الجدول
                var tblProps = new W.TableProperties(
                    new W.TableStyle() { Val = "TableGrid" },
                    new W.TableBorders(
                        new W.TopBorder() { Val = W.BorderValues.Single, Size = 6 },
                        new W.BottomBorder() { Val = W.BorderValues.Single, Size = 6 },
                        new W.LeftBorder() { Val = W.BorderValues.Single, Size = 6 },
                        new W.RightBorder() { Val = W.BorderValues.Single, Size = 6 },
                        new W.InsideHorizontalBorder() { Val = W.BorderValues.Single, Size = 6 },
                        new W.InsideVerticalBorder() { Val = W.BorderValues.Single, Size = 6 }
                    )
                );
                table.AppendChild(tblProps);

                // صف العناوين
                var headerRow = new W.TableRow();
                foreach (var h in headers)
                {
                    var cellPara = new W.Paragraph(new W.Run(new W.Text(h)))
                    {
                        ParagraphProperties = new W.ParagraphProperties(
                            new W.Justification() { Val = W.JustificationValues.Center })
                    };
                    cellPara.GetFirstChild<W.Run>()!.RunProperties =
                        new W.RunProperties(new W.Bold());

                    var cell = new W.TableCell(cellPara);
                    headerRow.Append(cell);
                }
                table.Append(headerRow);

                // صفوف البيانات
                foreach (var row in rows)
                {
                    var tr = new W.TableRow();
                    foreach (var col in row)
                    {
                        var p = new W.Paragraph(new W.Run(new W.Text(col ?? string.Empty)));
                        var tc = new W.TableCell(p);
                        tr.Append(tc);
                    }
                    table.Append(tr);
                }

                body.Append(table);
                mainPart.Document.Save();
            }

            return ms.ToArray();
        }

        // ====== DataTables JSON ======
        [HttpGet]
        public async Task<IActionResult> Data(string? role = null, string? q = null)
        {
            var dt = WebProject1.Infrastructure.DataTables.DataTablesRequest.From(Request, defaultOrderColumn: "Name");

            var src = _context.Users.AsNoTracking();

            if (!string.IsNullOrWhiteSpace(role))
                src = src.Where(u => (u.Role ?? "").ToLower() == role.ToLower());

            var search = dt.Search ?? q;
            if (!string.IsNullOrWhiteSpace(search))
                src = src.Where(u =>
                    (u.Name ?? "").Contains(search) ||
                    (u.Username ?? "").Contains(search) ||
                    (u.Email ?? "").Contains(search) ||
                    (u.Role ?? "").Contains(search));

            var total = await _context.Users.CountAsync();
            var filtered = await src.CountAsync();

            // ترتيب ديناميكي بسيط
            src = dt.OrderColumn switch
            {
                "Username" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Username) : src.OrderBy(x => x.Username)),
                "Email" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Email) : src.OrderBy(x => x.Email)),
                "Role" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Role) : src.OrderBy(x => x.Role)),
                _ => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Name) : src.OrderBy(x => x.Name)),
            };

            var page = await src
                .Skip(dt.Start)
                .Take(dt.Length)
                .Select(u => new
                {
                    u.Id,
                    u.Name,
                    u.Username,
                    u.Email,
                    u.Role
                })
                .ToListAsync();

            return Json(new
            {
                draw = dt.Draw,
                recordsTotal = total,
                recordsFiltered = filtered,
                data = page
            });
        }
    }
}
