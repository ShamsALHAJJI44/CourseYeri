﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.InkML;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Filters;
using WebProject1.Models;
using WebProject1.Models.Shared;
using WebProject1.Models.ViewModels;
using WebProject1.ViewModels;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly]
    public class CoursesController : AdminBaseController
    {
        private readonly ApplicationDbContext _context;
        private readonly IWebHostEnvironment _env;
        public CoursesController(ApplicationDbContext context, IWebHostEnvironment env)
        {
            _context = context; _env = env;
        }

        // GET: Courses
        // CoursesController
        public async Task<IActionResult> Index(int page = 1, int pageSize = 10)
        {
            var q = _context.Courses.AsNoTracking().OrderBy(c => c.Id);

            var total = await q.CountAsync();
            var items = await q.Skip((page - 1) * pageSize)
                               .Take(pageSize)
                               .ToListAsync();

            var vm = new PagedResult<Course>(items, total, page, pageSize);
            return View(vm);
        }



        // GET: Courses/Create
        public IActionResult Create()
        {
            ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name");
            return View();
        }

        public IActionResult Edit(int id)
        {
            var course = _context.Courses.Find(id);
            if (course == null)
                return NotFound();

            ViewBag.Categories = new SelectList(_context.Categories.ToList(), "Id", "Name", course.CategoryId);
            return View(course);
        }

        public IActionResult Delete(int id)
        {
            var course = _context.Courses.Include(c => c.Category).FirstOrDefault(c => c.Id == id);
            if (course == null)
                return NotFound();

            return View(course); // يفتح صفحة تأكيد
        }



        // POST: Courses/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create(Course course)
        {
            if (ModelState.IsValid)
            {
               Console.WriteLine("✅ نموذج صحيح، جاري الحفظ...");
                _context.Courses.Add(course);
                await _context.SaveChangesAsync();
                TempData["toast"] = "İşlem başarıyla tamamlandı.";
                return RedirectToAction(nameof(Index));
            }
            else
            {
                foreach (var error in ModelState.Values.SelectMany(v => v.Errors))
                {
                    Console.WriteLine("❌ خطأ في الإدخال: " + error.ErrorMessage);
                }

                // إذا فيه خطأ بالمدخلات، يرجع للفورم مع نفس الكاتغوري
                ViewBag.Categories = new SelectList(_context.Categories, "Id", "Name", course.CategoryId);
                return View(course);
            }

        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Course course)
        {
            if (id != course.Id)
                return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.Categories = new SelectList(_context.Categories.ToList(), "Id", "Name", course.CategoryId);
                return View(course);
            }

            _context.Courses.Update(course);
            _context.SaveChanges();
            TempData["toast"] = "İşlem başarıyla tamamlandı.";
            return RedirectToAction(nameof(Index));
        }
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var course = _context.Courses.Find(id);
            if (course == null)
                return NotFound();

            _context.Courses.Remove(course);
            _context.SaveChanges();
            TempData["toast"] = "Kullanıcı silindi.";
            return RedirectToAction(nameof(Index));
        }
        // GET: Courses/Details/5
        public IActionResult Details(int id)
        {
            var course = _context.Courses
                .Include(c => c.Category)
                .FirstOrDefault(c => c.Id == id);

            if (course == null) return NotFound();

            return View(course);
        }
        [HttpGet]
        public async Task<IActionResult> Data(int? categoryId = null, string? q = null)
        {
            var dt = WebProject1.Infrastructure.DataTables.DataTablesRequest.From(Request, defaultOrderColumn: "Title");

            // المصدر
            var src = _context.Courses
                .AsNoTracking()
                .Include(c => c.Category)
                .Select(c => new
                {
                    c.Id,
                    c.Title,
                    CategoryName = c.Category != null ? c.Category.Name : "",
                    // لو عندك حقل سعر (بدله/احذفه إذا غير موجود)
                    Price = (decimal?)EF.Property<decimal?>(c, "Price") ?? 0m,
                    // عدّاد التسجيلات (يعمل حتى لو ما عندك Navigation)
                    EnrollmentsCount = _context.Enrollments.Count(e => e.CourseId == c.Id)
                });

            // فلاتر
            if (categoryId.HasValue)
                src = src.Where(x => x.CategoryName != null && _context.Categories
                    .Where(cat => cat.Id == categoryId.Value)
                    .Select(cat => cat.Name).Contains(x.CategoryName));

            var search = dt.Search ?? q;
            if (!string.IsNullOrWhiteSpace(search))
                src = src.Where(x =>
                    x.Title.Contains(search) ||
                    x.CategoryName.Contains(search));

            var total = await _context.Courses.CountAsync();
            var filtered = await src.CountAsync();

            // ترتيب
            src = dt.OrderColumn switch
            {
                "CategoryName" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.CategoryName) : src.OrderBy(x => x.CategoryName)),
                "Price" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Price) : src.OrderBy(x => x.Price)),
                "EnrollmentsCount" => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.EnrollmentsCount) : src.OrderBy(x => x.EnrollmentsCount)),
                _ => (dt.OrderDir == "desc" ? src.OrderByDescending(x => x.Title) : src.OrderBy(x => x.Title)),
            };

            var page = await src
                .Skip(dt.Start)
                .Take(dt.Length)
                .ToListAsync();

            return Json(new
            {
                draw = dt.Draw,
                recordsTotal = total,
                recordsFiltered = filtered,
                data = page
            });
        }

        [HttpGet]
        public async Task<FileResult> ExportExcel(int? categoryId = null, string? q = null)
        {
            var data = _context.Courses
                .AsNoTracking()
                .Include(c => c.Category)
                .Select(c => new
                {
                    Başlık = c.Title,
                    Kategori = c.Category != null ? c.Category.Name : "",
                    Fiyat = (decimal?)EF.Property<decimal?>(c, "Price") ?? 0m,
                    KayıtSayısı = _context.Enrollments.Count(e => e.CourseId == c.Id)
                });

            if (categoryId.HasValue)
                data = data.Where(x => _context.Categories
                    .Where(cat => cat.Id == categoryId.Value)
                    .Select(cat => cat.Name).Contains(x.Kategori));

            if (!string.IsNullOrWhiteSpace(q))
                data = data.Where(x => x.Başlık.Contains(q) || x.Kategori.Contains(q));

            var list = await data.OrderBy(x => x.Başlık).ToListAsync();

            using var wb = new XLWorkbook();
            var ws = wb.Worksheets.Add("Courses");
            ws.Cell(1, 1).InsertTable(list);
            using var ms = new MemoryStream();
            wb.SaveAs(ms);

            return File(ms.ToArray(),
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                "courses.xlsx");
        }
        [HttpGet]
        public async Task<IActionResult> Related(int id)
        {
            var course = await _context.Courses.AsNoTracking().FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound();

            var all = await _context.Courses.AsNoTracking()
                         .Where(c => c.Id != id)
                         .OrderBy(c => c.Title).ToListAsync();

            var selectedIds = await _context.RelatedCourses
                                 .Where(rc => rc.CourseId == id)
                                 .Select(rc => rc.RelatedId)
                                 .ToListAsync();

            ViewBag.Course = course;
            ViewBag.AllCourses = all;
            ViewBag.Selected = selectedIds;

            return View(); // Views/Admin/Courses/Related.cshtml
        }

        // POST: /Admin/Courses/Related/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Related(int id, int[] selectedIds)
        {
            var course = await _context.Courses.FirstOrDefaultAsync(c => c.Id == id);
            if (course == null) return NotFound();

            var old = _context.RelatedCourses.Where(rc => rc.CourseId == id);
            _context.RelatedCourses.RemoveRange(old);

            var newLinks = selectedIds.Distinct()
                            .Where(relId => relId != id)
                            .Select(relId => new RelatedCourse { CourseId = id, RelatedId = relId });

            await _context.RelatedCourses.AddRangeAsync(newLinks);
            await _context.SaveChangesAsync();

            TempData["Ok"] = "İlişkili kurslar güncellendi.";
            return RedirectToAction(nameof(Related), new { id });
        }
        [HttpGet]
        public IActionResult UploadCover(int id)
        {
            var course = _context.Courses.Find(id);
            if (course == null) return NotFound();

            var vm = new CourseImageVM { CourseId = id };
            ViewBag.Course = course;
            return View(vm);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UploadCover(CourseImageVM model)
        {
            var course = await _context.Courses.FindAsync(model.CourseId);
            if (course == null) return NotFound();

            if (!ModelState.IsValid)
            {
                ViewBag.Course = course;
                return View(model);
            }

            if (model.ImageFile is not null && model.ImageFile.Length > 0)
            {
                var ext = Path.GetExtension(model.ImageFile.FileName).ToLowerInvariant();
                var fileName = $"{Guid.NewGuid():N}{ext}";
                var folder = Path.Combine(_env.WebRootPath, "images", "courses");
                Directory.CreateDirectory(folder);
                var fullPath = Path.Combine(folder, fileName);

                using var fs = System.IO.File.Create(fullPath);
                await model.ImageFile.CopyToAsync(fs);

                course.ImagePath = $"images/courses/{fileName}";
                await _context.SaveChangesAsync();

                TempData["Ok"] = "Kapak görseli güncellendi.";
                return RedirectToAction("Edit", new { id = course.Id });
            }

            ModelState.AddModelError("ImageFile", "Lütfen bir dosya seçiniz.");
            ViewBag.Course = course;
            return View(model);
        }

    }
}
