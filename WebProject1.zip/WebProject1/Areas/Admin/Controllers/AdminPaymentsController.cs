﻿using System.IO;
using ClosedXML.Excel;
// Open XML (بدون InkML)
using DocumentFormat.OpenXml;
using DocumentFormat.OpenXml.Packaging;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Elements.Table;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using WebProject1.Areas.Admin.Controllers;
using WebProject1.Data;
using WebProject1.Models.Enums;
using WebProject1.Services;
// Alias لأنواع الـ Wordprocessing لتجنّب التعارض:
using W = DocumentFormat.OpenXml.Wordprocessing;

[Area("Admin")]
//[Route("Admin/[controller]")]

public class AdminPaymentsController : AdminBaseController
{
    private readonly ApplicationDbContext _ctx;
    public AdminPaymentsController(ApplicationDbContext ctx) => _ctx = ctx;

    // GET: /Admin/AdminPayments
    [HttpGet()]
    public async Task<IActionResult> Index()
    {
        var list = await _ctx.Payments
            .Include(p => p.Enrollment).ThenInclude(e => e.User)
            .Include(p => p.Enrollment).ThenInclude(e => e.Course)
            .Include(p => p.Installments)
            .OrderByDescending(p => p.CreatedAt)
            .Select(p => new
            {
                PaymentId = p.Id,
                UserName = p.Enrollment.User.Name,
                Course = p.Enrollment.Course.Title,
                Total = p.TotalAmount,
                Paid = p.Installments.Where(i => i.IsPaid).Sum(i => (decimal?)i.Amount) ?? 0m,
                Remaining = p.Installments.Where(i => !i.IsPaid).Sum(i => (decimal?)i.Amount) ?? 0m,
                Status = p.Status,
                Overdues = p.Installments.Count(i => !i.IsPaid && i.DueDate < DateTime.Today)
            })
            .ToListAsync();

        return View(list);
    }

    // GET: /Admin/AdminPayments/Overdue
    [HttpGet()]
    public async Task<IActionResult> Overdue()
    {
        var items = await _ctx.PaymentInstallments
            .Include(i => i.Payment).ThenInclude(p => p.Enrollment).ThenInclude(e => e.User)
            .Include(i => i.Payment).ThenInclude(p => p.Enrollment).ThenInclude(e => e.Course)
            .Where(i => !i.IsPaid && i.DueDate < DateTime.Today)
            .OrderBy(i => i.DueDate)
            .Select(i => new
            {
                InstallmentId = i.Id,
                UserName = i.Payment.Enrollment.User.Name,
                Course = i.Payment.Enrollment.Course.Title,
                Amount = i.Amount,
                DueDate = i.DueDate,
                PaymentId = i.PaymentId
            })
            .ToListAsync();

        return View(items);
    }
    [HttpPost]
    public async Task<IActionResult> Remind(
     [FromServices] IInstallmentReminder reminder,
     CancellationToken ct)
    {
        await reminder.CheckAndNotifyAsync(ct);
        return Json(new { ok = true });
    }

    // GET: /Admin/AdminPayments/User/5
    [HttpGet()]
    public async Task<IActionResult> AppUser(int userId)
    {
        var payments = await _ctx.Payments
            .Include(p => p.Enrollment).ThenInclude(e => e.Course)
            .Include(p => p.Installments)
            .Where(p => p.Enrollment.UserId == userId)
            .OrderByDescending(p => p.CreatedAt)
            .ToListAsync();

        return View(payments);
    }

    [HttpGet("ExportToExcel")]
    [Route("[area]/[controller]/[action]")]
    public async Task<IActionResult> ExportToExcel(string? search = null, string? method = null, string? status = null, CancellationToken ct = default)
    {
        var q = _ctx.Payments
            .AsNoTracking()
            .Include(p => p.Enrollment).ThenInclude(e => e.User)
            .Include(p => p.Enrollment).ThenInclude(e => e.Course)
            .Include(p => p.Installments)
            .AsQueryable();

        var s = (search ?? string.Empty).Trim().ToLower();

        if (!string.IsNullOrWhiteSpace(s))
        {
            q = q.Where(p =>
                (p.Enrollment != null && p.Enrollment.User != null && (
                    (p.Enrollment.User.Name ?? "").ToLower().Contains(s) ||
                    (p.Enrollment.User.Username ?? "").ToLower().Contains(s) ||
                    (p.Enrollment.User.Email ?? "").ToLower().Contains(s)
                ))
                || (p.Enrollment != null && p.Enrollment.Course != null && (p.Enrollment.Course.Title ?? "").ToLower().Contains(s))
                || p.Id.ToString() == s
            );
        }

        if (!string.IsNullOrWhiteSpace(method))
        {
            var m = method.ToLower();
            q = q.Where(p => (m == "full" && p.Method == PaymentMethod.Full)
                          || (m == "installments" && p.Method == PaymentMethod.Installments));
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            var st = status.ToLower();
            q = q.Where(p =>
                (st == "paidfull" && p.Status == PaymentStatus.PaidFull) ||
                (st == "ongoing" && p.Status == PaymentStatus.InstallmentOngoing));
        }

        var rows = await q
     .OrderByDescending(p => p.CreatedAt)
     .Select(p => new
     {
         PaymentId = p.Id,

         Ogrenci = (p.Enrollment != null && p.Enrollment.User != null)
                     ? (p.Enrollment.User.Name ?? p.Enrollment.User.Username ?? "")
                     : "",

         Email = (p.Enrollment != null && p.Enrollment.User != null)
                     ? (p.Enrollment.User.Email ?? "")
                     : "",

         Kurs = (p.Enrollment != null && p.Enrollment.Course != null)
                     ? (p.Enrollment.Course.Title ?? "")
                     : "",

         Yontem = (p.Method == PaymentMethod.Full) ? "Peşin" : "Taksit",

         Durum = (p.Status == PaymentStatus.PaidFull) ? "Ödendi (Tam)"
              : (p.Status == PaymentStatus.InstallmentOngoing) ? "Taksit (Devam)"
              : p.Status.ToString(),

         Toplam = p.TotalAmount,
         TaksitAdet = (p.Installments != null) ? p.Installments.Count : 0,
         Olusturma = p.CreatedAt,
     })
     .ToListAsync(ct);


        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Odemeler");

        ws.Cell(1, 1).Value = "Payment #";
        ws.Cell(1, 2).Value = "Öğrenci";
        ws.Cell(1, 3).Value = "Email";
        ws.Cell(1, 4).Value = "Kurs";
        ws.Cell(1, 5).Value = "Yöntem";
        ws.Cell(1, 6).Value = "Durum";
        ws.Cell(1, 7).Value = "Toplam (₺)";
        ws.Cell(1, 8).Value = "Taksit Adedi";
        ws.Cell(1, 9).Value = "Oluşturma";

        var r = 2;
        foreach (var x in rows)
        {
            ws.Cell(r, 1).Value = x.PaymentId;
            ws.Cell(r, 2).Value = x.Ogrenci;
            ws.Cell(r, 3).Value = x.Email;
            ws.Cell(r, 4).Value = x.Kurs;
            ws.Cell(r, 5).Value = x.Yontem;
            ws.Cell(r, 6).Value = x.Durum;
            ws.Cell(r, 7).Value = (double)x.Toplam; // رقم حقيقي
            ws.Cell(r, 8).Value = x.TaksitAdet;
            ws.Cell(r, 9).Value = x.Olusturma;

            ws.Cell(r, 7).Style.NumberFormat.Format = "#,##0.00";
            ws.Cell(r, 9).Style.DateFormat.Format = "dd.MM.yyyy HH:mm";
            r++;
        }

        ws.Columns().AdjustToContents();

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        ms.Position = 0;

        var fileName = $"Odemeler_{DateTime.Now:yyyy-MM-dd_HH-mm}.xlsx";
        return File(ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            fileName);
    }


    // ========= Export to Word (Open XML SDK فقط) =========
    [HttpGet("ExportToWord")]
    [Route("[area]/[controller]/[action]")]
    public async Task<IActionResult> ExportToWord(string? search = null, string? method = null, string? status = null, CancellationToken ct = default)
    {
        var q = _ctx.Payments
            .AsNoTracking()
            .Include(p => p.Enrollment).ThenInclude(e => e.User)
            .Include(p => p.Enrollment).ThenInclude(e => e.Course)
            .Include(p => p.Installments)
            .AsQueryable();

        var s = (search ?? string.Empty).Trim().ToLower();

        if (!string.IsNullOrWhiteSpace(s))
        {
            q = q.Where(p =>
                (p.Enrollment != null && p.Enrollment.User != null && (
                    (p.Enrollment.User.Name ?? "").ToLower().Contains(s) ||
                    (p.Enrollment.User.Username ?? "").ToLower().Contains(s) ||
                    (p.Enrollment.User.Email ?? "").ToLower().Contains(s)
                ))
                || (p.Enrollment != null && p.Enrollment.Course != null && (p.Enrollment.Course.Title ?? "").ToLower().Contains(s))
                || p.Id.ToString() == s
            );
        }

        if (!string.IsNullOrWhiteSpace(method))
        {
            var m = method.ToLower();
            q = q.Where(p => (m == "full" && p.Method == PaymentMethod.Full)
                          || (m == "installments" && p.Method == PaymentMethod.Installments));
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            var st = status.ToLower();
            q = q.Where(p =>
                (st == "paidfull" && p.Status == PaymentStatus.PaidFull) ||
                (st == "ongoing" && p.Status == PaymentStatus.InstallmentOngoing));
        }

        var list = await q
            .OrderByDescending(p => p.CreatedAt)
            .ToListAsync(ct);

        using var ms = new MemoryStream();
        using (var doc = WordprocessingDocument.Create(ms, WordprocessingDocumentType.Document, true))
        {
            var mainPart = doc.AddMainDocumentPart();
            mainPart.Document = new W.Document(new W.Body());
            var body = mainPart.Document.Body;

            // عنوان
            var titlePara = new W.Paragraph(new W.Run(new W.Text("Ödeme Listesi")));
            titlePara.ParagraphProperties = new W.ParagraphProperties(new W.Justification { Val = W.JustificationValues.Center });
            titlePara.Descendants<W.Run>().First().RunProperties = new W.RunProperties(new W.Bold(), new W.FontSize { Val = "28" });
            body.AppendChild(titlePara);
            body.AppendChild(new W.Paragraph(new W.Run(new W.Text(" ")))); // مسافة

            // جدول + حدود
            var table = new W.Table(
                new W.TableProperties(
                    new W.TableStyle { Val = "TableGrid" },
                    new W.TableBorders(
                        new W.TopBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.BottomBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.LeftBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.RightBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.InsideHorizontalBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.InsideVerticalBorder { Val = W.BorderValues.Single, Size = 6 }
                    )
                )
            );

            string[] headers = { "Payment #", "Öğrenci", "Email", "Kurs", "Yöntem", "Durum", "Toplam (₺)", "Taksit Adedi", "Oluşturma" };

            // صف العناوين
            var headerRow = new W.TableRow();
            foreach (var h in headers)
            {
                var para = new W.Paragraph(new W.Run(new W.Text(h)));
                para.ParagraphProperties = new W.ParagraphProperties(new W.Justification { Val = W.JustificationValues.Center });
                para.GetFirstChild<W.Run>()!.RunProperties = new W.RunProperties(new W.Bold());
                headerRow.Append(new W.TableCell(para));
            }
            table.Append(headerRow);

            // دالة مساعدة للخلايا
            static W.TableCell Cell(string text) => new W.TableCell(new W.Paragraph(new W.Run(new W.Text(text ?? ""))));

            // البيانات
            foreach (var p in list)
            {
                string ogrenci = p.Enrollment?.User != null
                    ? (p.Enrollment.User.Name ?? p.Enrollment.User.Username ?? "")
                    : "";
                string email = p.Enrollment?.User?.Email ?? "";
                string kurs = p.Enrollment?.Course?.Title ?? "";
                string yontem = p.Method == PaymentMethod.Full ? "Peşin" : "Taksit";
                string durum = p.Status == PaymentStatus.PaidFull ? "Ödendi (Tam)"
                             : p.Status == PaymentStatus.InstallmentOngoing ? "Taksit (Devam)"
                             : p.Status.ToString();
                string toplam = p.TotalAmount.ToString("0.00");
                string taksitAdet = (p.Installments?.Count ?? 0).ToString();
                string olusturma = p.CreatedAt.ToString("dd.MM.yyyy HH:mm");

                var row = new W.TableRow();
                row.Append(
                    Cell(p.Id.ToString()),
                    Cell(ogrenci),
                    Cell(email),
                    Cell(kurs),
                    Cell(yontem),
                    Cell(durum),
                    Cell(toplam),
                    Cell(taksitAdet),
                    Cell(olusturma)
                );

                table.Append(row);
            }

            body.Append(table);
            mainPart.Document.Save();
        }

        var fileName = $"Odemeler_{DateTime.Now:yyyy-MM-dd_HH-mm}.docx";
        return File(ms.ToArray(),
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
            fileName);
    }
    [HttpGet("ExportToPdf")]
    [Route("[area]/[controller]/[action]")]
    public async Task<IActionResult> ExportToPdf(string? search = null, string? method = null, string? status = null)
    {
        var q = _ctx.Payments
            .AsNoTracking()
            .Include(p => p.Enrollment).ThenInclude(e => e.User)
            .Include(p => p.Enrollment).ThenInclude(e => e.Course)
            .Include(p => p.Installments)
            .AsQueryable();

        var s = (search ?? "").Trim().ToLower();
        if (!string.IsNullOrWhiteSpace(s))
        {
            q = q.Where(p =>
                (p.Enrollment.User != null && (
                    (p.Enrollment.User.Name ?? "").ToLower().Contains(s) ||
                    (p.Enrollment.User.Username ?? "").ToLower().Contains(s) ||
                    (p.Enrollment.User.Email ?? "").ToLower().Contains(s)
                ))
                || (p.Enrollment.Course != null && (p.Enrollment.Course.Title ?? "").ToLower().Contains(s))
                || p.Id.ToString() == s
            );
        }

        if (!string.IsNullOrWhiteSpace(method))
        {
            var m = method.ToLower();
            q = q.Where(p =>
                (m == "full" && p.Method == PaymentMethod.Full) ||
                (m == "installments" && p.Method == PaymentMethod.Installments));
        }

        if (!string.IsNullOrWhiteSpace(status))
        {
            var st = status.ToLower();
            q = q.Where(p =>
                (st == "paidfull" && p.Status == PaymentStatus.PaidFull) ||
                (st == "ongoing" && p.Status == PaymentStatus.InstallmentOngoing));
        }

        var rows = await q
            .OrderByDescending(p => p.CreatedAt)
            .Select(p => new
            {
                p.Id,
                Ogrenci = p.Enrollment != null && p.Enrollment.User != null
                            ? (p.Enrollment.User.Name ?? p.Enrollment.User.Username ?? "")
                            : "",
                Email = p.Enrollment != null && p.Enrollment.User != null ? (p.Enrollment.User.Email ?? "") : "",
                Kurs = p.Enrollment != null && p.Enrollment.Course != null ? (p.Enrollment.Course.Title ?? "") : "",
                Yontem = p.Method == PaymentMethod.Full ? "Peşin" : "Taksit",
                Durum = p.Status == PaymentStatus.PaidFull ? "Ödendi (Tam)"
                       : p.Status == PaymentStatus.InstallmentOngoing ? "Taksit (Devam)" : p.Status.ToString(),
                Toplam = p.TotalAmount,
                TaksitAdet = p.Installments != null ? p.Installments.Count : 0,
                Olusturma = p.CreatedAt
            })
            .ToListAsync();

        var pdfBytes = Document.Create(doc =>
        {
            doc.Page(p =>
            {
                p.Size(PageSizes.A4);
                p.Margin(15);
                p.DefaultTextStyle(x => x.FontSize(10));
                p.Header().Text("Ödeme Listesi").SemiBold().FontSize(16).AlignCenter();

                p.Content().Table(t =>
                {
                    t.ColumnsDefinition(c =>
                    {
                        c.ConstantColumn(55);   // Payment #
                        c.RelativeColumn(2);    // Öğrenci
                        c.RelativeColumn(3);    // Email
                        c.RelativeColumn(2);    // Kurs
                        c.RelativeColumn(1.2f); // Yöntem
                        c.RelativeColumn(1.6f); // Durum
                        c.RelativeColumn(1.2f); // Toplam
                        c.ConstantColumn(70);   // Taksit Adedi
                        c.RelativeColumn(1.8f); // Oluşturma
                    });

                    t.Header(h =>
                    {
                        HeaderCell(h.Cell(), "Payment #");
                        HeaderCell(h.Cell(), "Öğrenci");
                        HeaderCell(h.Cell(), "Email");
                        HeaderCell(h.Cell(), "Kurs");
                        HeaderCell(h.Cell(), "Yöntem");
                        HeaderCell(h.Cell(), "Durum");
                        HeaderCell(h.Cell(), "Toplam (₺)");
                        HeaderCell(h.Cell(), "Taksit Adedi");
                        HeaderCell(h.Cell(), "Oluşturma");
                    });

                    foreach (var r in rows)
                    {
                        DataCell(t.Cell(), r.Id.ToString());
                        DataCell(t.Cell(), r.Ogrenci);
                        DataCell(t.Cell(), r.Email);
                        DataCell(t.Cell(), r.Kurs);
                        DataCell(t.Cell(), r.Yontem);
                        DataCell(t.Cell(), r.Durum);
                        DataCell(t.Cell(), r.Toplam.ToString("0.##"));
                        DataCell(t.Cell(), r.TaksitAdet.ToString());
                        DataCell(t.Cell(), r.Olusturma.ToString("dd.MM.yyyy HH:mm"));
                    }
                });

                p.Footer().AlignRight().Text(DateTime.Now.ToString("dd.MM.yyyy HH:mm"));
            });
        }).GeneratePdf();

        var fileName = $"Odemeler_{DateTime.Now:yyyy-MM-dd_HH-mm}.pdf";
        return File(pdfBytes, "application/pdf", fileName);

        // ========== Helpers ==========
        static void HeaderCell(ITableCellContainer cell, string text) =>
            cell.Element(HeaderStyle).Text(text).SemiBold().AlignCenter();

        static void DataCell(ITableCellContainer cell, string? text) =>
            cell.Element(RowStyle).Text(text ?? "");

        static IContainer HeaderStyle(IContainer c) => c
            .Background(Colors.Grey.Lighten3)
            .BorderBottom(1).BorderColor(Colors.Grey.Medium)
            .PaddingVertical(6);

        static IContainer RowStyle(IContainer c) => c
            .BorderBottom(1).BorderColor(Colors.Grey.Lighten2)
            .PaddingVertical(4);
    }


    // (اختياري) Helper عام إن حبيتِ تستخدمينه لاحقاً
    private static byte[] BuildWordDocument(string title, string[] headers, List<string[]> rows)
    {
        using var ms = new MemoryStream();
        using (var doc = WordprocessingDocument.Create(ms, WordprocessingDocumentType.Document, true))
        {
            var mainPart = doc.AddMainDocumentPart();
            mainPart.Document = new W.Document(new W.Body());
            var body = mainPart.Document.Body;

            var titlePara = new W.Paragraph(new W.Run(new W.Text(title)));
            titlePara.ParagraphProperties = new W.ParagraphProperties(
                new W.Justification() { Val = W.JustificationValues.Center });
            titlePara.Descendants<W.Run>().First().RunProperties = new W.RunProperties(new W.Bold(), new W.FontSize() { Val = "28" });
            body.AppendChild(titlePara);
            body.AppendChild(new W.Paragraph(new W.Run(new W.Text(" "))));

            var table = new W.Table(
                new W.TableProperties(
                    new W.TableStyle { Val = "TableGrid" },
                    new W.TableBorders(
                        new W.TopBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.BottomBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.LeftBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.RightBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.InsideHorizontalBorder { Val = W.BorderValues.Single, Size = 6 },
                        new W.InsideVerticalBorder { Val = W.BorderValues.Single, Size = 6 }
                    )
                )
            );

            var headerRow = new W.TableRow();
            foreach (var h in headers)
            {
                var para = new W.Paragraph(new W.Run(new W.Text(h)));
                para.ParagraphProperties = new W.ParagraphProperties(
                    new W.Justification() { Val = W.JustificationValues.Center });
                para.GetFirstChild<W.Run>()!.RunProperties = new W.RunProperties(new W.Bold());
                headerRow.Append(new W.TableCell(para));
            }
            table.Append(headerRow);

            foreach (var row in rows)
            {
                var tr = new W.TableRow();
                foreach (var col in row)
                {
                    tr.Append(new W.TableCell(new W.Paragraph(new W.Run(new W.Text(col ?? string.Empty)))));
                }
                table.Append(tr);
            }

            body.Append(table);
            mainPart.Document.Save();
        }
        return ms.ToArray();
    }
}




