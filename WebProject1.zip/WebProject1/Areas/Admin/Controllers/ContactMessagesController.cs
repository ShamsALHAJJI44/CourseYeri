﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Filters;
using WebProject1.Models;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly] 
    public class ContactMessagesController : AdminBaseController
    {
        private readonly ApplicationDbContext _ctx;
        public ContactMessagesController(ApplicationDbContext ctx) => _ctx = ctx;

        public IActionResult Index()
        {
            var list = _ctx.ContactMessages
                           .OrderByDescending(m => m.CreatedAt)
                           .ToList();
            return View(list);
        }

        public IActionResult Details(int id)
        {
            var msg = _ctx.ContactMessages.FirstOrDefault(m => m.Id == id);
            if (msg == null) return NotFound();
            if (!msg.IsRead) { msg.IsRead = true; _ctx.SaveChanges(); }
            return View(msg);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Delete(int id)
        {
            var msg = _ctx.ContactMessages.Find(id);
            if (msg != null) { _ctx.ContactMessages.Remove(msg); _ctx.SaveChanges(); }
            return RedirectToAction(nameof(Index));
        }
    }
}
