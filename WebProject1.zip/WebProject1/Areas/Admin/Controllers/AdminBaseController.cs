﻿// Areas/Admin/Controllers/AdminBaseController.cs
using Microsoft.AspNetCore.Mvc;
using WebProject1.Filters;

namespace WebProject1.Areas.Admin.Controllers
{
    [Area("Admin")]
    [AdminOnly] // إن عندك فلتر صلاحيات
    public abstract class AdminBaseController : Controller { }
}
