﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.IO;

namespace WebProject1.Validation
{
    public class AllowedExtensionsAttribute : ValidationAttribute, IClientModelValidator
    {
        private readonly string[] _exts;
        public AllowedExtensionsAttribute(string[] exts) { _exts = exts; ErrorMessage = $"Sadece {string.Join(", ", exts)} uzantıları kabul edilir."; }

        protected override ValidationResult? IsValid(object? value, ValidationContext ctx)
        {
            if (value is IFormFile f && f.FileName is not null)
            {
                var ext = Path.GetExtension(f.FileName).ToLowerInvariant();
                if (!_exts.Contains(ext)) return new ValidationResult(ErrorMessage);
            }
            return ValidationResult.Success;
        }

        public void AddValidation(ClientModelValidationContext c)
        {
            if (!c.Attributes.ContainsKey("data-val")) c.Attributes.Add("data-val", "true");
            c.Attributes["data-val-allowedextensions"] = ErrorMessage!;
            c.Attributes["data-val-allowedextensions-exts"] = string.Join(",", _exts);
        }
    }

    public class MaxFileSizeAttribute : ValidationAttribute, IClientModelValidator
    {
        private readonly long _bytes;
        public MaxFileSizeAttribute(long bytes) { _bytes = bytes; ErrorMessage = $"Dosya boyutu en fazla {bytes / 1024 / 1024} MB olmalıdır."; }

        protected override ValidationResult? IsValid(object? value, ValidationContext ctx)
        {
            if (value is IFormFile f && f.Length > _bytes)
                return new ValidationResult(ErrorMessage);
            return ValidationResult.Success;
        }

        public void AddValidation(ClientModelValidationContext c)
        {
            if (!c.Attributes.ContainsKey("data-val")) c.Attributes.Add("data-val", "true");
            c.Attributes["data-val-maxfilesize"] = ErrorMessage!;
            c.Attributes["data-val-maxfilesize-bytes"] = _bytes.ToString();
        }
    }
}
