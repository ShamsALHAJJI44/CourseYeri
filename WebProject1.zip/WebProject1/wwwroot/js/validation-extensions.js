﻿// AllowedExtensions
$.validator.addMethod("allowedextensions", function (value, element, exts) {
    if (!value) return true;
    var ok = false, list = (exts || "").toLowerCase().split(",");
    var fileExt = (value.split(".").pop() || "").toLowerCase();
    for (var i = 0; i < list.length; i++) { if (("." + fileExt) === list[i].trim()) { ok = true; break; } }
    return ok;
});
$.validator.unobtrusive.adapters.addSingleVal("allowedextensions", "exts");

// MaxFileSize
$.validator.addMethod("maxfilesize", function (value, element, bytes) {
    if (!value || !element.files || !element.files[0]) return true;
    return element.files[0].size <= parseInt(bytes, 10);
});
$.validator.unobtrusive.adapters.addSingleVal("maxfilesize", "bytes");
