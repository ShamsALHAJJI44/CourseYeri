﻿// Sayfa gezinirken (link tıklanınca) listeyi iskeletle doldur.
(function () {
    const list = document.getElementById('course-list');
    if (!list) return;


    function renderSkeleton(count) {
        const grid = document.createElement('div');
        grid.className = 'course-grid';
        for (let i = 0; i < count; i++) {
            const wrap = document.createElement('div');
            wrap.className = 'course-card';
            const thumb = document.createElement('div');
            thumb.className = 'course-thumb skeleton skel-card';
            const body = document.createElement('div');
            body.className = 'course-body';
            for (let j = 0; j < 3; j++) {
                const l = document.createElement('div');
                l.className = 'skeleton skel-line';
                body.appendChild(l);
            }
            wrap.appendChild(thumb);
            wrap.appendChild(body);
            grid.appendChild(wrap);
        }
        return grid;
    }


    // Pagination linklerine skeleton etkisi ekle
    list.addEventListener('click', function (e) {
        const a = e.target.closest('a.page-link');
        if (!a) return;
        // Tam sayfa gezinme olacak; önce skeleton yerleştirip sonra tarayıcıyı bırakıyoruz
        list.innerHTML = '';
        list.appendChild(renderSkeleton(8));
    });
})();
(function () {
    const nav = document.querySelector('.user-navbar');
    if (!nav) return;
    const onScroll = () => nav.classList.toggle('is-scrolled', window.scrollY > 8);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
})();
