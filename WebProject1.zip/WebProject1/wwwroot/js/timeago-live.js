﻿(function () {
    function fmt(dt) {
        const now = new Date(), then = new Date(dt);
        const diff = (now - then) / 1000;
        if (diff < 45) return "az önce";
        if (diff < 120) return "1 dakika önce";
        if (diff < 3600) return Math.floor(diff / 60) + " dakika önce";
        if (diff < 7200) return "1 saat önce";
        if (diff < 86400) return Math.floor(diff / 3600) + " saat önce";
        const days = Math.floor(diff / 86400);
        if (days === 1) return "dün";
        if (days < 7) return days + " gün önce";
        if (days < 30) return Math.floor(days / 7) + " hafta önce";
        if (days < 365) return Math.floor(days / 30) + " ay önce";
        return Math.floor(days / 365) + " yıl önce";
    }

    function tick() {
        document.querySelectorAll('time[data-timeago="true"]').forEach(el => {
            const dt = el.getAttribute('datetime');
            if (dt) el.textContent = fmt(dt);
        });
    }
    tick();
    setInterval(tick, 60000);
})();
