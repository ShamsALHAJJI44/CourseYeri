﻿// wwwroot/js/userhome-ajax.js

(function () {
    const $list = document.getElementById('course-list');
    const $q = document.getElementById('q');
    const $cat = document.querySelector('select[name="categoryId"]');
    const $form = document.getElementById('filters');
    const $fav = document.querySelector('input[name="favoritesOnly"]');

    if (!$list || !$form) return;

    // ---- أدوات مساعدة ----
    const debounce = (fn, ms = 300) => {
        let t;
        return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
    };

    function skeleton(count = 8) {
        const grid = document.createElement('div');
        grid.className = 'course-grid';
        for (let i = 0; i < count; i++) {
            const card = document.createElement('div');
            card.className = 'course-card';
            const th = document.createElement('div');
            th.className = 'course-thumb skeleton skel-card';
            const body = document.createElement('div');
            body.className = 'course-body';
            for (let j = 0; j < 3; j++) {
                const l = document.createElement('div');
                l.className = 'skeleton skel-line';
                body.appendChild(l);
            }
            card.appendChild(th);
            card.appendChild(body);
            grid.appendChild(card);
        }
        return grid;
    }

    // نبني باراميترات طلب الـList (search/categoryId/page)
    function buildListParams(page = 1) {
        const params = new URLSearchParams();
        const qVal = $q && $q.value ? $q.value.trim() : '';
        const catVal = $cat && $cat.value ? $cat.value : '';
        if (qVal) params.set('search', qVal);        // الأكشن List يستقبل search
        if (catVal) params.set('categoryId', catVal);
        if ($fav && $fav.checked) params.set('favoritesOnly', 'true');
        params.set('page', page);
        return params;
    }

    // نحدّث شريط العنوان (URL) لصفحة Index ليحتفظ بـ q/categoryId (للتحديث/المشاركة)
    function updateIndexUrlInAddressBar(page = 1) {
        const urlParams = new URLSearchParams();
        const qVal = $q && $q.value ? $q.value.trim() : '';
        const catVal = $cat && $cat.value ? $cat.value : '';
        if (qVal) urlParams.set('q', qVal);          // Index يستعمل q
        if (catVal) urlParams.set('categoryId', catVal);
        if ($fav && $fav.checked) urlParams.set('favoritesOnly', 'true'); 
        if (page && page !== 1) urlParams.set('page', String(page));
        const newUrl = '/UserHome/Index' + (urlParams.toString() ? '?' + urlParams.toString() : '');
        history.replaceState({}, '', newUrl);
    }

    async function loadList(page = 1) {
        // سكيليتون
        $list.innerHTML = '';
        $list.appendChild(skeleton());

        // نبني URL للـ List (Partial)
        const params = buildListParams(page);
        const url = '/UserHome/List?' + params.toString();

        // نطلب الـHTML ونحقنه
        const html = await fetch(url, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(r => r.text())
            .catch(() => '<div class="empty-state"><h3>Bir hata oluştu</h3><p>Lütfen tekrar deneyiniz.</p></div>');

        $list.innerHTML = html;

        // نحدّث شريط العنوان ليعكس الحالة الحالية (Index + q/categoryId/page)
        updateIndexUrlInAddressBar(page);

        // نفعّل التقاط الضغط على روابط الـPagination لتكون AJAX
        wirePagination();
    }

    function wirePagination() {
        $list.querySelectorAll('a.page-link').forEach(a => {
            a.addEventListener('click', (e) => {
                e.preventDefault();
                // نستخرج رقم الصفحة من الرابط
                const u = new URL(a.href, location.origin);
                const p = parseInt(u.searchParams.get('page') || '1', 10);
                loadList(p);
            });
        });
    }

    // البحث الفوري: كتابة في q
    const doSearch = debounce(() => loadList(1), 300);
    $q && $q.addEventListener('input', doSearch);

    // تغيير التصنيف
    $cat && $cat.addEventListener('change', () => loadList(1));
    $fav && $fav.addEventListener('change', () => loadList(1));

    // منع الإرسال الكامل للفورم إذا ضغط المستخدم Enter أو زر "Uygula"
    $form.addEventListener('submit', (e) => {
        e.preventDefault();
        loadList(1);
    });

    // دعم زر الرجوع/التقدّم (popstate): يعيد تحميل النتائج حسب URL الحالي
    window.addEventListener('popstate', () => {
        // نقرأ q/categoryId من العنوان ونحدّث الحقول ثم نحمّل النتائج
        const cur = new URL(location.href);
        const qVal = cur.searchParams.get('q') || '';
        const catVal = cur.searchParams.get('categoryId') || '';
        const favVal = cur.searchParams.get('favoritesOnly') === 'true';
        if ($q) $q.value = qVal;
        if ($cat) $cat.value = catVal;
        const page = parseInt(cur.searchParams.get('page') || '1', 10);
        loadList(page);
    });

    // ربط أولي لروابط الـPagination الموجودة حاليًا
    wirePagination();
})();
