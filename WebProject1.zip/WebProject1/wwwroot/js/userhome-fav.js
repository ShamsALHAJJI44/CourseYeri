﻿// wwwroot/js/userhome-fav.js
document.addEventListener('click', async (e) => {
    const btn = e.target.closest('.fav-btn');
    if (!btn) return;

    const id = btn.getAttribute('data-course-id');
    try {
        const token = document.querySelector('input[name="__RequestVerificationToken"]')?.value;
        const r = await fetch('/UserHome/FavoriteToggle?courseId=' + id, {
            method: 'POST',
            headers: { 'X-Requested-With': 'XMLHttpRequest', 'RequestVerificationToken': token }
        });

        if (r.status === 401) { alert('Lütfen giriş yapınız'); return; }
        const j = await r.json();
        if (j.ok) {
            btn.setAttribute('aria-pressed', j.isFav ? 'true' : 'false');
            btn.classList.toggle('btn-outline-secondary', !j.isFav);
            btn.classList.toggle('btn-secondary', j.isFav);
        }
    } catch (_) {
        alert('Bir hata oluştu. Lütfen tekrar deneyiniz.');
    }
});
