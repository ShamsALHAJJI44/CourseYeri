﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Text.Encodings.Web;
using System.Text.RegularExpressions;

namespace WebProject1.Helpers.Html
{
    public static class HighlightHelper
    {
        public static IHtmlContent Highlight(this IHtmlHelper html, string? text, string? term)
        {
            text ??= string.Empty;
            if (string.IsNullOrWhiteSpace(term)) return new HtmlString(HtmlEncoder.Default.Encode(text));

            var safeText = HtmlEncoder.Default.Encode(text);
            var safeTerm = Regex.Escape(term);
            var result = Regex.Replace(safeText, safeTerm, m => $"<mark>{m.Value}</mark>", RegexOptions.IgnoreCase);
            return new HtmlString(result);
        }
    }
}
