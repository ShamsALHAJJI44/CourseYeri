﻿using Microsoft.EntityFrameworkCore;

namespace WebProject1.Models
{
    public class PaymentInstallment
    {
        public int Id { get; set; }

        public int PaymentId { get; set; }
        public Payment Payment { get; set; }

        public int Sequence { get; set; } // 1 أو 2

        [Precision(18, 2)]
        public decimal Amount { get; set; }

        public DateTime DueDate { get; set; }   // موعد الاستحقاق
        public bool IsPaid { get; set; } = false;
        public DateTime? PaidAt { get; set; }
    }
}
