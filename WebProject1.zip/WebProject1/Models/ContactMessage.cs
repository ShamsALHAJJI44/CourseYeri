﻿using System.ComponentModel.DataAnnotations;

namespace WebProject1.Models
{
    public class ContactMessage
    {
        public int Id { get; set; }

        [Required, MaxLength(120)]
        public required string Name { get; set; }

        [Required, EmailAddress, MaxLength(160)]
        public required string Email { get; set; }

        [Required, MinLength(10)]
        public required string Message { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public bool IsRead { get; set; } = false;
    }
}
