﻿using Microsoft.EntityFrameworkCore;
using WebProject1.Models;

public class Favorite
{
    public int UserId { get; set; }
    public int CourseId { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

    public User? User { get; set; }
    public Course? Course { get; set; }
}

