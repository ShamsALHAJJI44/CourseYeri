﻿using System.ComponentModel.DataAnnotations;

namespace WebProject1.Models
{
    public class User
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Ad Soyad zorunludur")]
        [MaxLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Kullanıcı adı zorunludur")]
        [MaxLength(50)]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email zorunludur")]
        [EmailAddress(ErrorMessage = "Geçerli bir email giriniz")]
        [MaxLength(150)]
        public string Email { get; set; } = string.Empty;

        // ⚠️ ترِكها مَحكّية مؤقتاً لتُقرأ من DB، وبعد الترقيه نخليها NULL
        [MaxLength(200)]
        public string? Password { get; set; }

        // PBKDF2
        [MaxLength(256)]
        public string? PasswordHash { get; set; }
        [MaxLength(128)]
        public string? PasswordSalt { get; set; }

        [Required]
        [MaxLength(20)]
        public string Role { get; set; } = "user";

        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        public ICollection<Favorite> Favorites { get; set; } = new List<Favorite>();


        // لإعادة التعيين:
        public string? ResetToken { get; set; }
        public DateTime? ResetTokenExpiresAt { get; set; }

    }
}
