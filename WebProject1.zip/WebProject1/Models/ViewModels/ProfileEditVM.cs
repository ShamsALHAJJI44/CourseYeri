﻿using System.ComponentModel.DataAnnotations;

namespace WebProject1.Models
{
    public class ProfileEditVM
    {
        [Display(Name = "Kullanıcı Adı")]
        public string Username { get; set; } = string.Empty; // للعرض فقط

        [Required(ErrorMessage = "İsim zorunludur")]
        [Display(Name = "İsim")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email zorunludur")]
        [EmailAddress(ErrorMessage = "Geçerli bir email giriniz")]
        [Display(Name = "E-posta")]
        public string Email { get; set; } = string.Empty;

        // تغيير كلمة المرور (اختياري)
        [Display(Name = "Eski Şifre")]
        public string? OldPassword { get; set; }

        [MinLength(6, ErrorMessage = "Şifre en az 6 karakter olmalı")]
        [Display(Name = "Yeni Şifre")]
        public string? NewPassword { get; set; }

        [Compare("NewPassword", ErrorMessage = "Şifreler eşleşmiyor")]
        [Display(Name = "Yeni Şifre (Tekrar)")]
        public string? ConfirmNewPassword { get; set; }
    }
}
