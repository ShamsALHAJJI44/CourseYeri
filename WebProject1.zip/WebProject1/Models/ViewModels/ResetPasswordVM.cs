﻿using System.ComponentModel.DataAnnotations;
namespace WebProject1.Models
{
    public class ResetPasswordVM
    {
        [Required] public string Token { get; set; } = "";
        [Required, MinLength(6, ErrorMessage = "Şifre en az 6 karakter")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; } = "";
        [Compare(nameof(NewPassword), ErrorMessage = "Şifreler uyuşmuyor")]
        [DataType(DataType.Password)]
        public string ConfirmPassword { get; set; } = "";
    }
}