﻿using System;
using System.Collections.Generic;
using System.Linq; // مهم للخصائص المحسوبة (Where/Sum/Count)

namespace WebProject1.Models.ViewModels
{
    // ===== الأقساط =====
    public class PaymentInstallmentVM
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public DateTime DueDate { get; set; }
        public bool IsPaid { get; set; }
        public DateTime? PaidAt { get; set; }

        // حالات العرض
        public bool IsOverdue { get; set; }  // متأخر
        public bool IsDueSoon { get; set; }  // خلال 3 أيام
    }

    // ===== سجل العمليات =====
    public class TransactionVM
    {
        public int Id { get; set; }
        public decimal Amount { get; set; }
        public string Method { get; set; } = "";   // Kredi Kartı, Havale, vb.
        public string Status { get; set; } = "";   // Başarılı, Bekliyor, Hatalı
        public DateTime Date { get; set; }
    }

    // ===== الدفع الرئيسي =====
    public class PaymentVM
    {
        public int Id { get; set; }
        public string CourseTitle { get; set; } = "";
        public decimal TotalAmount { get; set; }
        public DateTime CreatedAt { get; set; }
        public string Method { get; set; } = "";   // Peşin / Taksit
        public string Status { get; set; } = "";   // Ödendi (Tam) / Taksit (Devam Ediyor)
        public bool IsFullPaid { get; set; }

        public List<PaymentInstallmentVM> Installments { get; set; } = new();

        // 👇 أضفناها لسجل العمليات
        public List<TransactionVM> Transactions { get; set; } = new();

        // ---- خصائص محسوبة للواجهة ----
        public decimal RemainingBalance => Installments.Where(i => !i.IsPaid).Sum(i => i.Amount);
        public decimal PaidAmount => Installments.Where(i => i.IsPaid).Sum(i => i.Amount);

        public int PaidPercentage
        {
            get
            {
                if (TotalAmount == 0) return 0;
                return (int)Math.Round((PaidAmount / TotalAmount) * 100m);
            }
        }
    }
}
