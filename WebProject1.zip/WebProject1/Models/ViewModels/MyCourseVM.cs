﻿using System;

using WebProject1.Models.Enums; // لو enum عندك بمكان آخر عدّلي الـ using

namespace WebProject1.ViewModels
{
    public class MyCourseVM
    {
        public int CourseId { get; set; }
        public string Title { get; set; } = string.Empty;
        public string ImagePath { get; set; } = string.Empty;
        public string Description { get; set; } = string.Empty;
        public string Duration { get; set; } = string.Empty;
        public string CategoryName { get; set; } = string.Empty;

        public DateTime EnrollmentDate { get; set; }

        // حالة الدفع حسب Enrollment.PaymentStatus
        public PaymentStatus PaymentStatus { get; set; }

        // (اختياري) معلومات القسط التالي إن أردتِ عرضها لاحقًا
        public DateTime? NextInstallmentDue { get; set; }
        public decimal? NextInstallmentAmount { get; set; }
    }
}
