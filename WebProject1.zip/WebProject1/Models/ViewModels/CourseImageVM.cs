﻿using Microsoft.AspNetCore.Http;
using System.ComponentModel.DataAnnotations;
using WebProject1.Validation;

namespace WebProject1.ViewModels
{
    public class CourseImageVM
    {
        [Required]
        public int CourseId { get; set; }

        [AllowedExtensions(new[] { ".jpg", ".jpeg", ".png", ".webp" })]
        [MaxFileSize(2 * 1024 * 1024)]
        [Display(Name = "Kurs Kapak Görseli")]
        public IFormFile? ImageFile { get; set; }
    }
}
