﻿using System.ComponentModel.DataAnnotations;
namespace WebProject1.Models
{
    public class ForgotPasswordVM
    {
        [Required(ErrorMessage = "Kullanıcı adı veya e-posta zorunlu")]
        public string UsernameOrEmail { get; set; } = "";
    }
}