﻿namespace WebProject1.ViewModels
{
    public class CourseCardVm
    {
        public int Id { get; set; }
        public string? Title { get; set; }
        public string? CategoryName { get; set; }

        // رح نمرّر ImagePath من الـCourse لهون
        public string? ThumbnailUrl { get; set; }

        public decimal Price { get; set; }
        public string ImagePath { get; set; } = "";
        public bool IsFavorite { get; set; }
        // الضرورية لعرض النجوم على الكرت
        public decimal AverageStars { get; set; }  // <— كانت ناقصة
        public string ShortDescription { get; set; }

    }
}
