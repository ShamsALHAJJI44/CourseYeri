﻿using System.Collections.Generic;
using WebProject1.Models.ViewModels;

namespace WebProject1.ViewModels
{
    public class PagedCoursesVm
    {
        public IEnumerable<CourseCardVm> Items { get; set; } = new List<CourseCardVm>();

        public int Page { get; set; } = 1;
        public int PageSize { get; set; } = 12;
        public bool HasNext { get; set; }
        public int TotalCount { get; set; }

        public string? Search { get; set; }
        public int? CategoryId { get; set; }
        public string? Sort { get; set; }
        public decimal? MinPrice { get; set; }
        public decimal? MaxPrice { get; set; }
        public bool FavoritesOnly { get; set; }
        public bool IsEmpty => TotalCount == 0;
    }
}
