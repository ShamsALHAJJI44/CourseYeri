﻿namespace WebProject1.Models.Dashboard
{
    public class DashboardVM
    {
        public int UsersCount { get; set; }
        public int CoursesCount { get; set; }
        public int CategoriesCount { get; set; }
        public int EnrollmentsCount { get; set; }

        public List<User> LatestUsers { get; set; } = new();
        public List<Course> LatestCourses { get; set; } = new();
        public List<Enrollment> LatestEnrollments { get; set; } = new();

        // Line chart (حقيقي من DB)
        public List<string> MonthLabels { get; set; } = new();
        public List<int> EnrollmentsByMonth { get; set; } = new();

        // Donut (Top 3 Courses by Enrollments)
        public List<string> TopCoursesLabels { get; set; } = new();   // ex: ["AI", "C#", "SQL"]
        public List<int> TopCoursesCounts { get; set; } = new();      // ex: [25, 18, 12]

        // Category Distribution (Top 5)
        public List<(string name, int value, int percent)> CategoryDist { get; set; } = new();
    }
}
