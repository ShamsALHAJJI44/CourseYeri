﻿namespace WebProject1.Models.ViewModels
{
    public class AgreementVM
    {
        public int CourseId { get; set; }
        public string? Type { get; set; }
        public bool Accepted { get; set; }
    }
}
