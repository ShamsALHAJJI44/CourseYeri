﻿using System.ComponentModel.DataAnnotations;

namespace WebProject1.Models
{
    public class ContactVM
    {
        [Required(ErrorMessage = "Ad Soyad zorunludur")]
        [Display(Name = "Ad Soyad")]
        public string Name { get; set; } = string.Empty;

        [Required(ErrorMessage = "Email zorunludur")]
        [EmailAddress(ErrorMessage = "Geçerli bir email giriniz")]
        [Display(Name = "E-posta")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "Mesaj zorunludur")]
        [MinLength(10, ErrorMessage = "Mesaj en az 10 karakter olmalı")]
        [Display(Name = "Mesaj")]
        public string Message { get; set; } = string.Empty;
    }
}
