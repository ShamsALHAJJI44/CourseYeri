﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;

namespace WebProject1.Models
{
    public class Category
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Kategori adı zorunludur")]
        public required string Name { get; set; }

        [ValidateNever]
        public required ICollection<Course> Courses { get; set; } = new List<Course>();


    }
}
