﻿using Microsoft.EntityFrameworkCore;
using WebProject1.Models.Enums;

namespace WebProject1.Models
{
    public class Payment
    {
        public int Id { get; set; }

        public int EnrollmentId { get; set; }
        public Enrollment Enrollment { get; set; } 

        public PaymentMethod Method { get; set; }
        public PaymentStatus Status { get; set; } = PaymentStatus.Pending;

        [Precision(18, 2)]
        public decimal TotalAmount { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public ICollection<PaymentInstallment> Installments { get; set; }
    }
}
