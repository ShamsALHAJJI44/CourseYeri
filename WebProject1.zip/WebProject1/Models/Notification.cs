﻿namespace WebProject1.Models
{
    public class Notification
    {
        public int Id { get; set; }

        // لمن يخصّ التنبيه
        public int UserId { get; set; }

        // عنوان مختصر + رسالة
        public string Title { get; set; } = "";
        public string Message { get; set; } = "";

        // رابط اختياري (ليفتح تفاصيل الدفع مثلاً)
        public string? LinkUrl { get; set; }

        // ربط اختياري مع دفع/قسط
        public int? PaymentId { get; set; }
        public int? InstallmentId { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
        public bool IsRead { get; set; } = false;

        public bool IsForAdmin { get; set; } = false;
    }
}
