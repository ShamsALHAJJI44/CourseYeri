﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;

namespace WebProject1.Models
{
    public class Course
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "Başlık alanı zorunludur")]
        public required string Title { get; set; }

        [Required(ErrorMessage = "Açıklama alanı zorunludur")]
        public required string Description { get; set; }

        [Required(ErrorMessage = "Resim yolu zorunludur")]
        public required string ImagePath { get; set; }

        [Precision(18, 2)]
        [Range(0, 100000, ErrorMessage = "Fiyat 0 ile 100000 arasında olmalı")]
        public decimal Price { get; set; }

        [Required(ErrorMessage = "Süre bilgisi zorunludur")]
        public required string Duration { get; set; }

        [Required(ErrorMessage = "Kategori seçilmelidir")]
        public int CategoryId { get; set; }

        public Category? Category { get; set; }

        [Display(Name = "Tanıtım Videosu (isteğe bağlı)")]
        public string? IntroVideoUrl { get; set; }

        [Display(Name = "Ek Talimatlar (isteğe bağlı)")]
        public string? Instructions { get; set; }

        public ICollection<RelatedCourse> RelatedCourses { get; set; } = new List<RelatedCourse>(); // ما يرتبط به
        public ICollection<RelatedCourse> RelatedTo { get; set; } = new List<RelatedCourse>(); // من يرتبط به
        public ICollection<Favorite> Favorites { get; set; } = new List<Favorite>();

    }
}

