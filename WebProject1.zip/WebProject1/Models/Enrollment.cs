﻿using System;
using System.ComponentModel.DataAnnotations;
using WebProject1.Models.Enums;

namespace WebProject1.Models
{
    public class Enrollment
    {
        public int Id { get; set; }

        [Required]
        public int UserId { get; set; }
        public User? User { get; set; }

        [Required]
        public int CourseId { get; set; }
        public Course? Course { get; set; }

        [Display(Name = "Kayıt Tarihi")]
        public DateTime EnrollmentDate { get; set; } = DateTime.Now;


        public bool IsActive { get; set; } = false;
        public PaymentStatus PaymentStatus { get; set; } = PaymentStatus.Pending;
    }
}
