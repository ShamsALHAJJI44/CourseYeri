﻿namespace WebProject1.Models.Enums
{
    public enum PaymentStatus
    {
        Pending = 0,            // لم يُسدَّد بعد
        PaidFull = 1,           // مدفوع بالكامل
        InstallmentOngoing = 2, // تقسيط جارٍ (1 مدفوع، 2 لم يحن/لم يُدفع)
        Overdue = 3,            // متأخر
        Cancelled = 4           // أُلغي الاشتراك بسبب التأخر
    }
}
