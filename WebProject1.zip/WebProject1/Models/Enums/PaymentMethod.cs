﻿namespace WebProject1.Models.Enums
{
    public enum PaymentMethod
    {
        Full = 1,        // دفع كامل
        Installments = 2 // تقسيط (دفعتين)
    }
}
