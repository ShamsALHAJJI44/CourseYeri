﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;

namespace WebProject1.Models
{
    public class UserCreateVM
    {
        public int? Id { get; set; }

        [Required(ErrorMessage = "Kullanıcı adı zorunlu")]
        [Remote(action: "CheckUsername", controller: "Users", areaName: "Admin",
                AdditionalFields = nameof(Id),
                ErrorMessage = "Kullanıcı adı zaten mevcut")]
        public string Username { get; set; } = string.Empty;

        [Required, EmailAddress]
        [Remote(action: "CheckEmail", controller: "Users", areaName: "Admin",
                AdditionalFields = nameof(Id),
                ErrorMessage = "Email zaten kayıtlı")]
        public string Email { get; set; } = string.Empty;

        [Required, MinLength(6)]
        public string Password { get; set; } = string.Empty;

        public string Role { get; set; } = "user";
        public string Name { get; set; } = string.Empty;
    }
}
