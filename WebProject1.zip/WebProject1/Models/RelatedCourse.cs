﻿using System;
namespace WebProject1.Models
{
    // جدول وصل يربط الدورة بدورات أخرى مقترحة/مرتبطة
    public class RelatedCourse
    {
        public int CourseId { get; set; }
        public int RelatedId { get; set; }

        public Course? Course { get; set; }
        public Course? Related { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}
