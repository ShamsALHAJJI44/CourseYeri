﻿using System.ComponentModel.DataAnnotations;

namespace WebProject1.Models
{
    public class Review
    {
        public int Id { get; set; }
        [Required] public int CourseId { get; set; }
        [Required] public int UserId { get; set; }
        [Range(1, 5, ErrorMessage = "1-5")] public int Stars { get; set; }
        [MaxLength(500)] public string? Comment { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;

        public Course? Course { get; set; }
    }
}
