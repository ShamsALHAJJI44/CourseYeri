﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace WebProject1.Extensions
{
    public static class HtmlHelpers
    {
        public static IHtmlContent Price(this IHtmlHelper html, decimal value)
            => new HtmlString($"{value:0.##} ₺");

        public static string ActiveClass(this IHtmlHelper html, string controller, string? action = null, string active = "active")
        {
            var rd = html.ViewContext.RouteData.Values;
            var c = (rd["controller"]?.ToString() ?? "");
            var a = (rd["action"]?.ToString() ?? "");
            var ok = string.Equals(c, controller, StringComparison.OrdinalIgnoreCase)
                     && (action == null || string.Equals(a, action, StringComparison.OrdinalIgnoreCase));
            return ok ? active : "";
        }
    }
}
