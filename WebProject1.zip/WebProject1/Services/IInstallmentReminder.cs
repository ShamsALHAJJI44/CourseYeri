﻿using System.Threading;
using System.Threading.Tasks;

namespace WebProject1.Services
{
    public interface IInstallmentReminder
    {
        Task CheckAndNotifyAsync(CancellationToken ct = default);
       // Task RemindInstallmentAsync(int id);
    }
}
