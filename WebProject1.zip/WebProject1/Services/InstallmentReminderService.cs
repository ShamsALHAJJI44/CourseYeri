﻿using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace WebProject1.Services
{
    public class InstallmentReminderService : BackgroundService
    {
        private readonly IServiceProvider _services;
        private readonly ILogger<InstallmentReminderService> _logger;

        public InstallmentReminderService(IServiceProvider services, ILogger<InstallmentReminderService> logger)
        {
            _services = services;
            _logger = logger;
        }

        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            _logger.LogInformation("InstallmentReminderService started.");

#if DEBUG
            var period = TimeSpan.FromMinutes(1);   // دقيقة أثناء التطوير
#else
            var period = TimeSpan.FromHours(24);    // مرة باليوم بالإنتاج
#endif

            while (!stoppingToken.IsCancellationRequested)
            {
                try
                {
                    using var scope = _services.CreateScope();
                    var reminder = scope.ServiceProvider.GetRequiredService<IInstallmentReminder>();

                    await reminder.CheckAndNotifyAsync(stoppingToken);

                    _logger.LogInformation("Installment reminders checked and notifications sent if needed.");
                }
                catch (Exception ex)
                {
                    _logger.LogError(ex, "Error running InstallmentReminderService loop.");
                }

                try
                {
                    await Task.Delay(period, stoppingToken);
                }
                catch (TaskCanceledException)
                {
                    // app shutting down
                }
            }

            _logger.LogInformation("InstallmentReminderService stopped.");
        }
    }
}
