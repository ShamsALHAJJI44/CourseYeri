﻿// Services/SmtpEmailSender.cs
using System.Net;
using System.Net.Mail;

namespace WebProject1.Services
{
    public class SmtpEmailSender : IEmailSender
    {
        private readonly string _from;
        private readonly string _password;

        public SmtpEmailSender(IConfiguration config)
        {
            _from = config["Email:From"] ?? "";
            _password = config["Email:AppPassword"] ?? "";
        }

        public async Task SendAsync(string toEmail, string subject, string htmlBody)
        {
            if (string.IsNullOrWhiteSpace(_from) || string.IsNullOrWhiteSpace(_password))
            {
                Console.WriteLine("[Email] Missing From/AppPassword in appsettings.");
                return;
            }

            try
            {
                using var smtp = new SmtpClient("smtp.gmail.com", 587)
                {
                    EnableSsl = true,
                    DeliveryMethod = SmtpDeliveryMethod.Network,
                    UseDefaultCredentials = false,
                    Credentials = new NetworkCredential(_from, _password),
                    Timeout = 10000
                };

                using var mail = new MailMessage
                {
                    From = new MailAddress(_from),
                    Subject = subject ?? string.Empty,
                    Body = htmlBody ?? string.Empty,
                    IsBodyHtml = true
                };
                mail.To.Add(toEmail);

                await smtp.SendMailAsync(mail);
                Console.WriteLine("[Email] Sent OK → " + toEmail);
            }
            catch (Exception ex)
            {
                Console.WriteLine("[Email] FAILED: " + ex.Message);
                // لو بدك تشوف التفاصيل أكتر:
                Console.WriteLine(ex.ToString());
            }
        }
    }
}
