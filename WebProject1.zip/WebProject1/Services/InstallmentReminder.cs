﻿using System.Threading;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Models;

namespace WebProject1.Services
{
    public class InstallmentReminder : IInstallmentReminder
    {
        private readonly ApplicationDbContext _ctx;
        private readonly INotificationService _notif;
        private readonly IEmailSender _email;

        public InstallmentReminder(ApplicationDbContext ctx, INotificationService notif, IEmailSender email)
        {
            _ctx = ctx;
            _notif = notif;
            _email = email;
        }

        public async Task CheckAndNotifyAsync(CancellationToken ct = default)
        {
            var today = DateTime.Today;
            var dueSoon = today.AddDays(3);

            // الأقساط المتأخرة + المستحقة خلال 3 أيام
            var installments = await _ctx.PaymentInstallments
                .Include(i => i.Payment)
                    .ThenInclude(p => p.Enrollment)
                        .ThenInclude(e => e.User)
                .Where(i => !i.IsPaid && i.DueDate.Date <= dueSoon)
                .ToListAsync(ct);

            foreach (var inst in installments)
            {
                var user = inst.Payment?.Enrollment?.User;
                if (user == null) continue;

                bool isOverdue = inst.DueDate.Date < today;
                string title = isOverdue ? "Geciken Taksit" : "Yaklaşan Taksit";
                string msg = isOverdue
                    ? $"#{inst.Id} numaralı taksidiniz gecikti."
                    : $"#{inst.Id} numaralı taksidiniz 3 gün içinde ödenecek.";

                // منع تكرار نفس الإشعار
                var exists = await _notif.ExistsSimilarAsync(user.Id, title, msg, inst.PaymentId, inst.Id);
                if (!exists)
                {
                    await _notif.AddAsync(new Notification
                    {
                        UserId = user.Id,
                        Title = title,
                        Message = msg,
                        PaymentId = inst.PaymentId,
                        InstallmentId = inst.Id,
                        // إن كانت تفاصيل الدفع لديك تحت الأدمِن:
                        LinkUrl = $"/Admin/AdminPayments/Details/{inst.PaymentId}",
                        // وإن كان مسارك سابقًا عامًا فاستخدم:
                        // LinkUrl    = $"/Payment/Details/{inst.PaymentId}",
                        CreatedAt = DateTime.Now,
                        IsRead = false
                    });
                }

                // إرسال إيميل (لو متاح)
                if (!string.IsNullOrWhiteSpace(user.Email))
                {
                    var displayName = string.IsNullOrWhiteSpace(user.Username)
                        ? (user.Email.Split('@').FirstOrDefault() ?? "öğrenci")
                        : user.Username;

                    await _email.SendAsync(
                        user.Email,
                        title,
                        $"Merhaba {displayName},<br/>{msg}<br/>" +
                        $"Tutar: {inst.Amount:N2} ₺<br/>" +
                        // طابق نفس الرابط المستعمل بالأعلى
                        $"Detay: <a href=\"/Admin/AdminPayments/Details/{inst.PaymentId}\">Ödeme Detayı</a>"
                    // أو:
                    // $"Detay: <a href=\"/Payment/Details/{inst.PaymentId}\">Ödeme Detayı</a>"
                    );
                }
            }
        }
    }
}
