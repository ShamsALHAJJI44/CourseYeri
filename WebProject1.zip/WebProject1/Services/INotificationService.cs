﻿using System.Threading.Tasks;
using System.Collections.Generic;
using WebProject1.Models;

namespace WebProject1.Services
{
    public interface INotificationService
    {
        Task<int> GetUnreadCountAsync(int userId);
        Task<List<Notification>> GetLatestAsync(int userId, int take = 10);
        Task<List<Notification>> GetUserNotificationsAsync(int userId, int take = 10);

        Task AddAsync(Notification n);
        Task MarkAsReadAsync(int id, int userId);
        Task MarkAllAsReadAsync(int userId);
        Task<bool> ExistsSimilarAsync(int userId, string title, string message, int? paymentId, int? installmentId);
    }
}

