﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WebProject1.Data;
using WebProject1.Models;

namespace WebProject1.Services
{
    public class NotificationService : INotificationService
    {
        private readonly ApplicationDbContext _ctx;

        public NotificationService(ApplicationDbContext ctx) => _ctx = ctx;

        public async Task<int> GetUnreadCountAsync(int userId)
        {
            return await _ctx.Notifications
                .Where(n => n.UserId == userId && !n.IsRead)
                .CountAsync();
        }

        public async Task<List<Notification>> GetLatestAsync(int userId, int take = 10)
        {
            return await _ctx.Notifications
                .Where(n => n.UserId == userId)
                .OrderByDescending(n => n.CreatedAt)
                .Take(take)
                .ToListAsync();
        }

        public async Task AddAsync(Notification n)
        {
            // تأكيد القيم الأساسية
            if (n == null) throw new ArgumentNullException(nameof(n));
            n.CreatedAt = n.CreatedAt == default ? DateTime.Now : n.CreatedAt;
            n.IsRead = n.IsRead; // اتركها كما أرسلت (غالباً false للإشعارات الجديدة)

            _ctx.Notifications.Add(n);
            await _ctx.SaveChangesAsync();
        }

        public async Task MarkAsReadAsync(int id, int userId)
        {
            var notif = await _ctx.Notifications
                .FirstOrDefaultAsync(x => x.Id == id && x.UserId == userId);

            if (notif == null) return;

            if (!notif.IsRead)
            {
                notif.IsRead = true;
                await _ctx.SaveChangesAsync();
            }
        }

        public async Task MarkAllAsReadAsync(int userId)
        {
            var unread = await _ctx.Notifications
                .Where(x => x.UserId == userId && !x.IsRead)
                .ToListAsync();

            if (unread.Count == 0) return;

            foreach (var n in unread)
                n.IsRead = true;

            await _ctx.SaveChangesAsync();
        }

        public async Task<bool> ExistsSimilarAsync(
            int userId, string title, string message, int? paymentId, int? installmentId)
        {
            // تحقّق أساسي لتفادي التكرار (يمكنك تضييق الشروط حسب حاجتك)
            return await _ctx.Notifications.AnyAsync(n =>
                n.UserId == userId &&
                n.Title == title &&
                n.Message == message &&
                n.PaymentId == paymentId &&
                n.InstallmentId == installmentId &&
                !n.IsRead
            );
        }
        public async Task<List<Notification>> GetUserNotificationsAsync(int userId, int take = 10)
        {
            return await _ctx.Notifications
                .Where(n => n.UserId == userId)
                .OrderByDescending(n => n.CreatedAt)
                .Take(take)
                .ToListAsync();
        }

    }
}
