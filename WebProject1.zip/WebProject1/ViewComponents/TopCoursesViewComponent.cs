﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;

namespace WebProject1.ViewComponents
{
    public class TopCoursesViewComponent : ViewComponent
    {
        private readonly ApplicationDbContext _ctx;
        public TopCoursesViewComponent(ApplicationDbContext ctx) => _ctx = ctx;

        public async Task<IViewComponentResult> InvokeAsync(int take = 3)
        {
            var data = await _ctx.Enrollments
                .Include(e => e.Course)
                .Where(e => e.Course != null)
                .GroupBy(e => e.Course!.Title)
                .Select(g => new { Title = g.Key, Count = g.Count() })
                .OrderByDescending(x => x.Count)
                .Take(take)
                .ToListAsync();

            return View(data);
        }
    }
}
