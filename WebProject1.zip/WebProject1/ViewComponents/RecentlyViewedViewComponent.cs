﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.ViewModels;

public class RecentlyViewedViewComponent : ViewComponent
{
    private readonly ApplicationDbContext _ctx;
    public RecentlyViewedViewComponent(ApplicationDbContext ctx) { _ctx = ctx; }

    public async Task<IViewComponentResult> InvokeAsync()
    {
        var raw = HttpContext.Request.Cookies["rv"];
        var ids = string.IsNullOrWhiteSpace(raw) ? new List<int>() :
                  raw.Split(',').Select(int.Parse).ToList();

        var courses = await _ctx.Courses.AsNoTracking().Include(c => c.Category)
                        .Where(c => ids.Contains(c.Id)).ToListAsync();

        var ordered = ids.Select(i => courses.FirstOrDefault(c => c.Id == i)).Where(c => c != null)!;
        var vms = ordered.Select(c => new CourseCardVm
        {
            Id = c!.Id,
            Title = c.Title,
            CategoryName = c.Category?.Name,
            ThumbnailUrl = c.ImagePath,
            Price = c.Price,
            IsFavorite = false
        });
        return View(vms);
    }
}
