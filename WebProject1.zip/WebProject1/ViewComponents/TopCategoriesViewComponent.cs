﻿using System;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;


namespace WebProject1.ViewComponents
{
    [ResponseCache(Duration = 300, Location = ResponseCacheLocation.Any, NoStore = false)]
    public class TopCategoriesViewComponent : ViewComponent
    {
        private readonly ApplicationDbContext _ctx;
        public TopCategoriesViewComponent(ApplicationDbContext ctx)
        {
            _ctx = ctx;
        }


        public async Task<IViewComponentResult> InvokeAsync(int take = 8)
        {
            var cats = await _ctx.Categories
            .AsNoTracking()
            .OrderByDescending(c => c.Courses.Count) // popülerlik
            .Take(take)
            .Select(c => new { c.Id, c.Name })
            .ToListAsync();


            return View(cats);
        }
    }
}