﻿using Microsoft.AspNetCore.Mvc.ModelBinding;
using System.Globalization;

namespace WebProject1.Infrastructure
{
    public class DecimalModelBinder : IModelBinder
    {
        public Task BindModelAsync(ModelBindingContext bc)
        {
            var val = bc.ValueProvider.GetValue(bc.ModelName);
            if (val == ValueProviderResult.None) return Task.CompletedTask;

            var str = val.FirstValue?.Trim();
            if (string.IsNullOrEmpty(str)) return Task.CompletedTask;

            // قبول النقطة أو الفاصلة
            str = str.Replace(" ", "").Replace(",", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator)
                     .Replace(".", CultureInfo.CurrentCulture.NumberFormat.NumberDecimalSeparator);

            if (decimal.TryParse(str, NumberStyles.Number, CultureInfo.GetCultureInfo("tr-TR"), out var d))
            {
                bc.Result = ModelBindingResult.Success(d);
            }
            else
            {
                bc.ModelState.TryAddModelError(bc.ModelName, "Geçersiz sayı formatı");
            }
            return Task.CompletedTask;
        }
    }
}
