﻿using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.EntityFrameworkCore;
using WebProject1.Data;
using WebProject1.Models.Enums;

namespace WebProject1.Infrastructure.Filters
{
    public class InstallmentDueFilter : IAsyncActionFilter
    {
        private readonly ApplicationDbContext _ctx;
        public InstallmentDueFilter(ApplicationDbContext ctx) => _ctx = ctx;

        public async Task OnActionExecutionAsync(ActionExecutingContext context, ActionExecutionDelegate next)
        {
            var http = context.HttpContext;
            var userId = http.Session.GetInt32("UserId");
            if (userId != null)
            {
                var tomorrow = DateTime.Today.AddDays(1);
                var today = DateTime.Today;

                // تنبيه قبل يوم
                var dueTomorrow = await _ctx.PaymentInstallments
                    .Include(i => i.Payment).ThenInclude(p => p.Enrollment).ThenInclude(e => e.Course)
                    .Where(i => !i.IsPaid && i.DueDate.Date == tomorrow && i.Payment.Enrollment.UserId == userId)
                    .ToListAsync();

                if (dueTomorrow.Any())
                    http.Items["InstallmentReminder"] = $"Yarın ({tomorrow:dd.MM.yyyy}) ödenmesi gereken {dueTomorrow.Count} taksidiniz var.";

                // إيقاف عند التأخير
                var overdue = await _ctx.PaymentInstallments
                    .Include(i => i.Payment).ThenInclude(p => p.Enrollment)
                    .Where(i => !i.IsPaid && i.DueDate.Date < today && i.Payment.Enrollment.UserId == userId)
                    .ToListAsync();

                if (overdue.Any())
                {
                    foreach (var inst in overdue)
                    {
                        var enr = inst.Payment.Enrollment;
                        enr.IsActive = false;
                        enr.PaymentStatus = PaymentStatus.Overdue;
                    }
                    await _ctx.SaveChangesAsync();

                    http.Items["InstallmentOverdue"] = "Gecikmiş taksit(ler) bulundu. İlgili kurs kaydınız askıya alındı.";
                }
            }

            await next();
        }
    }
}
