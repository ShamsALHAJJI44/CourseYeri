﻿namespace WebProject1.Infrastructure.DataTables
{
    public class DataTablesRequest
    {
        public int Draw { get; set; }
        public int Start { get; set; }
        public int Length { get; set; }
        public string? Search { get; set; }
        public string? OrderColumn { get; set; }
        public string? OrderDir { get; set; } // "asc" | "desc"

        public static DataTablesRequest From(HttpRequest req, string defaultOrderColumn = "Id")
        {
            var q = req.Query;
            return new DataTablesRequest
            {
                Draw = int.TryParse(q["draw"], out var d) ? d : 1,
                Start = int.TryParse(q["start"], out var s) ? s : 0,
                Length = int.TryParse(q["length"], out var l) ? l : 10,
                Search = q["search[value]"].ToString()?.Trim(),
                OrderColumn = q[$"columns[{q["order[0][column]"]}][data]"].ToString() ?? defaultOrderColumn,
                OrderDir = q["order[0][dir]"].ToString() ?? "asc"
            };
        }
    }
}
