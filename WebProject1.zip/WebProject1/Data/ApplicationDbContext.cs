﻿using Microsoft.EntityFrameworkCore;
using WebProject1.Models;

namespace WebProject1.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Course> Courses { get; set; }
        public DbSet<Enrollment> Enrollments { get; set; }
        public DbSet<ContactMessage> ContactMessages { get; set; }
        public DbSet<Payment> Payments { get; set; }
        public DbSet<PaymentInstallment> PaymentInstallments { get; set; }
        public DbSet<Notification> Notifications { get; set; } = null!;
        public DbSet<Favorite> Favorites { get; set; } = null!;
        public DbSet<Review> Reviews { get; set; } = null!;
    //    public DbSet<RelatedCourse> RelatedCourses { get; set; } = null!;

        //protected override void OnModelCreating(ModelBuilder builder)
        //{
        //    base.OnModelCreating(builder);

        //    builder.Entity<Favorite>(entity =>
        //    {
        //        entity.HasKey(f => new { f.UserId, f.CourseId });

        //        entity.HasOne(f => f.Course)
        //              .WithMany()               // ما عندنا Navigation عكسي على Course الآن
        //              .HasForeignKey(f => f.CourseId)
        //              .OnDelete(DeleteBehavior.Cascade);
        //    });

        //    // ... بقية إعداداتك (إن وُجدت)
        //}

        public DbSet<RelatedCourse> RelatedCourses { get; set; }  // أضف DbSet

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<RelatedCourse>(e =>
            {
                e.HasKey(rc => new { rc.CourseId, rc.RelatedId });

                e.HasOne(rc => rc.Course)
                 .WithMany(c => c.RelatedCourses)
                 .HasForeignKey(rc => rc.CourseId)
                 .OnDelete(DeleteBehavior.Cascade);

                // لتفادي حلقات الحذف المتسلسلة، خليه Restrict على الجهة الثانية
                e.HasOne(rc => rc.Related)
                 .WithMany(c => c.RelatedTo)
                 .HasForeignKey(rc => rc.RelatedId)
                 .OnDelete(DeleteBehavior.Restrict);
            });
            builder.Entity<Favorite>(e =>
            {
                e.HasKey(f => new { f.UserId, f.CourseId });

                e.HasOne(f => f.Course)
                 .WithMany(c => c.Favorites)
                 .HasForeignKey(f => f.CourseId)
                 .OnDelete(DeleteBehavior.Cascade);

                e.HasOne(f => f.User)
                 .WithMany(u => u.Favorites)
                 .HasForeignKey(f => f.UserId)
                 .OnDelete(DeleteBehavior.Cascade);
            });

        }


    }
}
